import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
import java.util.Arrays;

public class Pst0041_SuperEvent {

	static StringTokenizer ST;
	static StringBuilder RESULT;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int Q;
	static int S = 131072;
	static int V[] = new int[S * 2]; // 1 ~ 100,000 중에서 나올 숫자를 알 수 없기 때문

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = new StringBuilder();
		ANSWER = new StringBuilder();

		Q = Integer.parseInt(BR.readLine().trim());

		Arrays.fill(V, 0);

	}

	static void process() throws Exception {

		int a, n;
		for (int i = 0; i < Q; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			n = Integer.parseInt(ST.nextToken());
			if (a == 1) update(n - 1 + S, true);	// 뽑은 숫자의 개수 증가
			else query(n);							// 당첨된(n번째) 숫자 탐색
		}

	}

	static void update(int id, boolean isAdd) { // 숫자를 뽑을 때 +1, 숫자가 당첨되었을 때 -1

		while (id > 0) {

			V[id] += isAdd ? 1 : -1;
			id >>= 1;

		}

	}

	static void query(int n) {

		int id = 1;	// 루트 노드에서 탐색 시작

		while (id < S) {

			if (V[id * 2] < n) {		// 왼쪽 자식의 숫자 개수가 찾으려는 순위보다 작을 때
				n -= V[id * 2];			// n에서 왼쪽 자식의 숫자 개수만큼 빼고 오른쪽 자식으로 이동
				id = id * 2 + 1;

			} else {					// 왼쪽 자식의 숫자 개수보다 찾으려는 순위가 같거나 작을 때
				id = id * 2;			// 왼쪽 자식으로 이동

			}

		}

		RESULT.append(id - S + 1).append(' ');	// V 배열에서의 인덱스를 숫자로 변환

		update(id, false);						// 당첨된 숫자 개수 감소

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}