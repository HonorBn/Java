import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Pre0028_Combat {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N;			// 총 팀 수
	static int outCNT;		// 탈락한 팀 수
	static int OUT[];		// 팀별 탈락 시간
	static int prevOUT[];	// 1분 전 팀별 탈락 시간
	static Team T[];		// 팀별 좌표

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		T = new Team[N];
		OUT = new int[N];
		prevOUT = new int[N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			T[i] = new Team(new Player(Long.parseLong(ST.nextToken()), Long.parseLong(ST.nextToken())),
							new Player(Long.parseLong(ST.nextToken()), Long.parseLong(ST.nextToken())));
		}

	}

	static void process() throws Exception {

		// 초기화
		outCNT = 0;
		Arrays.fill(OUT, 32);

		// 시간별 전투 및 이동
		for (int t = 0; t < 32; t++) {

			fight(t);										// 전투

			if (outCNT == N) break;							// 모두 탈락할 경우 게임 종료

			move();											// 기본 이동

			if (t == 9 || t == 19 || t == 29) moveMore(t);	// 추가 이동

		}

	}

	static void fight(int t) {

		// 이전 탈락 시간 복사
		for (int i = 0; i < N; i++) prevOUT[i] = OUT[i];

		// 전투 판정
		for (int i = 0; i < N; i++) {
			for (int j = i + 1; j < N; j++) {

				if (prevOUT[i] < 32 || prevOUT[j] < 32) continue;	// 이미 탈락한 팀 제외

				if (T[i].meet(T[j])) {			// 전투 발생하면, 탈락 시간 저장 및 탈락한 팀 수 증가

					if (OUT[i] == 32) {
						OUT[i] = t;
						outCNT++;
					}

					if (OUT[j] == 32) {
						OUT[j] = t;
						outCNT++;
					}

				}

			}
		}

	}

	static void move() {

		for (int i = 0; i < N; i++) {

			if (OUT[i] < 32)
				continue;
			T[i].move();

		}
	}

	static void moveMore(int t) {

		for (int i = 0; i < N; i++) {

			if (OUT[i] < 32)
				continue;
			T[i].moveMore(t);

		}
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#');
		ANSWER.append(tc);
		for (int i = 0; i < N; i++) ANSWER.append(' ').append(OUT[i]);
		ANSWER.append('\n');

		BW.write(ANSWER.toString());

	}

}

class Player implements Comparable<Player> {
	long x, y;
	Player(long x, long y) {
		this.x = x;
		this.y = y;
	}
	void move() {
		x /= 2; y /= 2;
	}
	void moveMore(int t) {
		if (t == 9) {
			if (x > 0 && y < 0) this.x *= -1;
		} else if (t == 19) {
			if (x < 0 && y < 0) this.y *= -1;
		} else {
			if (x < 0 && y > 0) this.x *= -1;
		}
	}
	@Override
	public int compareTo(Player that) {
		if (this.x != that.x) return this.x < that.x ? -1 : 1;
		else return this.y < that.y ? -1 : this.y > that.y ? 1 : 0;
	}

}

class Team {
	Player a, b;
	Team(Player a, Player b) {
		this.a = a;
		this.b = b;
	}
	void move() {
		a.move(); b.move();
	}
	void moveMore(int t) {
		a.moveMore(t); b.moveMore(t);
	}
	boolean meet(Team that) {
		int ccwThis = ccw(this.a, this.b, that.a) * ccw(this.a, this.b, that.b);
		int ccwThat = ccw(that.a, that.b, this.a) * ccw(that.a, that.b, this.b);
		if (ccwThis == 0 && ccwThat == 0) {
			if (this.a.compareTo(this.b) > 0) swap(this.a, this.b);
			if (that.a.compareTo(that.b) > 0) swap(that.a, that.b);
			if (this.a.compareTo(that.b) <= 0 && that.a.compareTo(this.b) <= 0) return true;
		} else if (ccwThis <= 0 && ccwThat <= 0) {
			return true;
		}
		return false;
	}
	private int ccw(Player a, Player b, Player c) {
		long ccw = a.x * b.y + b.x * c.y + c.x * a.y - a.y * b.x - b.y * c.x - c.y * a.x;
		if (ccw > 0) return 1;
		else if (ccw < 0) return -1;
		else return 0;
	}
	private void swap(Player a, Player b) {
		long tmpX = a.x; long tmpY = a.y;
		a.x = b.x; a.y = b.y;
		b.x = tmpX; b.y = tmpY;
	}

}