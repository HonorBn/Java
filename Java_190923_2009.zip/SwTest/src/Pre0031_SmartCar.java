import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
import java.util.Arrays;

public class Pre0031_SmartCar {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, S, E, lower, upper, group[], RESULT;
	static Road roads[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = Integer.MAX_VALUE;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken().trim());
		M = Integer.parseInt(ST.nextToken().trim());

		roads = new Road[M];
		group = new int[N + 1];

		int a, b, s;
		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken().trim());
			b = Integer.parseInt(ST.nextToken().trim());
			s = Integer.parseInt(ST.nextToken().trim());
			roads[i] = new Road(a, b, s);
		}

		ST = new StringTokenizer(BR.readLine().trim());
		S = Integer.parseInt(ST.nextToken().trim());
		E = Integer.parseInt(ST.nextToken().trim());

	}

	static void process() throws Exception {

		Arrays.sort(roads);

		int tmpUp;
		boolean canGo;
		for (int i = 0; i < M; i++) {

			tmpUp = i;
			canGo = false;
			upper = 0;
			lower = roads[i].s;

			for (int j = 1; j <= N; j++) group[j] = j;

			for (int j = tmpUp; j < M; j++) {

				union(roads[j]);

				if (find(group[S]) == find(group[E])) {
					tmpUp = j;
					canGo = true;
					RESULT = RESULT < upper - lower ? RESULT : upper - lower;
					break;
				}

			}

			if (!canGo) break;

		}

	}

	static int find(int a) {
		if (group[a] == a) return a;
		else return group[a] = find(group[a]);
	}

	static void union(Road road) {

		int a = find(road.a);
		int b = find(road.b);

		if (a == b) return;

		group[a] = b;
		upper = road.s > upper ? road.s : upper;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class Road implements Comparable<Road> {
	int a, b, s;

	Road(int from, int to, int s) {
		this.a = from;
		this.b = to;
		this.s = s;
	}

	@Override
	public int compareTo(Road that) {
		return this.s - that.s;
	}
}