import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class Pre0023_Card2 {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K, M, RESULT, card[];
	static Map<Integer, Integer> map = new HashMap<>();

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());

		M = N / 2;
		
		map.clear();
		card = new int[N];
		
		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			card[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {
		
		left(0, 0);
		right(M, 0);
		
	}
	
	static void left(int id, int sum) {
		
		if (id == M) {									// 왼쪽 절반인 card[0 ~ M-1]를 모두 고려했을 때 
			if (map.get(sum) == null) map.put(sum, 1);	// 해당 부분집합의 합 개수를 저장
			else map.put(sum, map.get(sum) + 1);
			return;
		}
		
		left(id + 1, sum);				// 현재 index 선택하지 않는 경우
		left(id + 1, sum + card[id]);	// 현재 index 선택하는 경우
		
	}

	static void right(int id, int sum) {
		
		if (id == N) {									// 오른쪽 절반인 card[M ~ N-1]를 모두 고려했을 때
			if (map.get(K - sum) == null) RESULT += 0;	// K에서 해당 부분집합의 합을 뺀 나머지가
			else RESULT += map.get(K - sum);			// 기존에 구한 왼쪽 절반의 부분집합의 합에 있으면,
			return;										// 해당 개수만큼 증가
		}
		
		right(id + 1, sum);				// 현재 index 선택하지 않는 경우
		right(id + 1, sum + card[id]);	// 현재 index 선택하는 경우
		
	}
	
	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}