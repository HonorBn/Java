import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	주어진 숫자에서 i번째 숫자 list[i]를 제외한 최대공약수 Ex[i]를 구하면
	최대 N(N-2)회 연산을 하므로 시간 초과.
	 Ex[1] : GCD(list[N], GCD(list[N-1], ..., GCD(list[3], list[2]) ... )
	 Ex[2] : GCD(list[N], GCD(list[N-1], ..., GCD(list[3], list[1]) ... )
	 ...
	 Ex[N] : GCD(list[N-1], GCD(list[N-2], ..., GCD(list[2], list[1]) ... )
	
	먼저 N번째 숫자를 제외하는 경우를 보면,
	
	1번째 숫자부터 N-1번째 숫자까지의 최대공약수 dp1[N-1]과 list[N]이 있을 때
	list[N]이 dp1[N-1]의 배수가 아니면 list[N]을 제외한 Ex[N]이 최댓값 K가 된다
	
	  i	│	...			N-2			N-1			N
	────┼───────────────────────────────────────────
	list│	...			a^2*b*c		b*c			a*c
	dp1	│	...			a^2*b		b			1		라고 가정하면,
	
	최대공약수의 최댓값이었던 dp1[N-1]에서 list[N] 때문에 인수 b가 제거되기 때문이다
	
	반대로, list[N]이 dp1[N-1]의 배수이면 Ex[N]보다 크거나 같은 Ex[i]가 존재한다
	
	  i	│	...			N-2			N-1			N
	────┼───────────────────────────────────────────
	list│	...			a^2*b*c		b*c			a*b
	dp1	│	...			a^2*b		b			b		라고 가정하면,
	
	이 경우 항상 dp1[N-1] = dp1[N] 이고, dp1[N-1]은 dp1[N-2]보다 작거나 같다
	
	
	다음으로 1번째 숫자를 제외하는 경우를 보면,
	(위와 상황은 동일하고 최대공약수를 N번째 숫자부터 1번째 숫자까지 거꾸로 계산)
	
	N번째 숫자부터 2번째 숫자까지의 최대공약수 dp2[2]과 list[1]이 있을 때
	list[1]이 dp2[2]의 배수가 아니면 list[1]을 제외한 Ex[1]이 최댓값 K가 된다
	
	  i	│	1			2			3			...
	────┼───────────────────────────────────────────
	list│	a*c			b*c			a^2*b*c		...
	dp2	│	1			b			a^2*b		...		라고 가정하면,
	
	최대공약수의 최댓값이었던 dp2[2]에서 list[1] 때문에 인수 b가 제거되기 때문이다
	
	반대로, list[1]이 dp2[2]의 배수이면 Ex[1]보다 크거나 같은 Ex[i]가 존재한다
	
	  i	│	1			2			3			...
	────┼───────────────────────────────────────────
	list│	a*b			b*c			a^2*b*c		...
	dp2	│	b			b			a^2*b		...		라고 가정하면,
	
	이 경우 항상 dp2[2] = dp2[1] 이고, dp2[2]는 dp2[3]보다 작거나 같다
	
	
	마지막으로 i번째 숫자를 제외하는 경우를 보면,
	
	list[i], dp1[i-1], dp2[i+1]이 있을 때
	list[i]가 GCD(dp1[i-1], dp2[i+1])의 배수가 아니면
	Ex[i]가 최댓값 K의 후보이고 Ex[1]부터 Ex[N]까지 K를 갱신하면 답을 구할 수 있다
	
	  i	│	...			i-1			i			i+1			...
	────┼───────────────────────────────────────────
	list│	...			a*b*c		a*c			b*c*d		...
	dp1	│	...			a*b			a			1			...
	dp2	│	...			c			c			b*c*d		...		라고 가정하면,
	
	GCD(dp1[i-1], dp2[i+1]) = b 이고
	list[i]를 제외하면 구하려는 최종 최대공약수에서 인수 b가 유지되기 때문이다
	
	반대로, list[i]가 GCD(dp1[i-1], dp2[i+1])의 배수이면
	Ex[i]보다 큰 Ex[j]가 존재한다 (j != i)
	
	  i	│	...			i-1			i			i+1			...
	────┼───────────────────────────────────────────
	list│	...			a*b*c		b*c			b*c*d		...
	dp1	│	...			a*b			b			b			...
	dp2	│	...			b*c			b*c			b*c*d		...		라고 가정하면,
	
	GCD(dp1[i-1], dp2[i+1]) = b 이고
	list[i]를 포함하면 구하려는 최종 최대공약수에서 인수 b가 유지되기 때문이다
	
	덧붙여서,
	이후에 어떤 j (i < j)에 대해 list[j]가 인수 b를 가지지 않으면
	구하려는 최종 최대공약수에서 유지되고 있던 인수 b가 제거되기 때문에
	K의 최댓값은 Ex[j]가 된다
	또한, 모든 j (i < j)에 대해 list[j]가 인수 b를 가지고 있으면
	이전에 갱신된 가장 큰 K가 답이 된다 (위 예시에서 maxK = Ex[i] = ... = Ex[N])
*/

public class Pst0033_Duck {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, exN, maxK;
	static int list[], dp1[], dp2[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		exN = 0;
		maxK = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		list = new int[N + 1];
		dp1 = new int[N + 1];
		dp2 = new int[N + 1];

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 1; i <= N; i++)
			list[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {

		// 1번째 숫자부터 N번째 숫자까지의 최대공약수 dp1[i] 계산
		dp1[1] = list[1];
		for (int i = 2; i <= N; i++)
			dp1[i] = gcd(dp1[i - 1], list[i]);

		// N번째 숫자부터 1번째 숫자까지의 최대공약수 dp[i] 계산
		dp2[N] = list[N];
		for (int i = N - 1; i >= 1; i--)
			dp2[i] = gcd(dp2[i + 1], list[i]);

		int g;
		for (int i = 1; i <= N; i++) {

			if (i == 1) g = dp2[2];					// Ex[1]을 고려할 때 dp2[2]만 사용
			else if (i == N) g = dp1[N - 1];		// Ex[N]을 고려할 때 dp1[N-1]만 사용
			else g = gcd(dp1[i - 1], dp2[i + 1]);	// Ex[i]를 고려할 때
													// GCD(dp1[i-1], dp2[i+1]) 사용

			if (list[i] % g > 0 && g > maxK) {		// list[i]가 g의 배수가 아니고
				maxK = g;							// g가 지금까지 갱신된 K보다 클 때 최댓값 갱신
				exN = list[i];
			}

		}

	}

	static int gcd(int a, int b) {
		if (b == 0) return a;
		else return gcd(b, a % b);
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(maxK).append(' ').append(exN).append('\n');

		BW.write(ANSWER.toString());

	}

}