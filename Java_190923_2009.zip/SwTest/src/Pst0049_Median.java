import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Pst0049_Median {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K, M, S, max, RESULT;
	static int tree[], sortedIndex[];
	static Median[] data;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		max = 0;
		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());

		M = K / 2;

		data = new Median[N];
		sortedIndex = new int[N];

		int num;
		ST = new StringTokenizer(BR.readLine().trim());	// K = 1일 때를 위해 최댓값 저장
		for (int i = 0; i < N; i++) {
			num = Integer.parseInt(ST.nextToken());
			data[i] = new Median(i, num);
			if (max < num) max = num;
		}

	}

	static void process() throws Exception {

		if (K == 1) {		// 구간 크기가 1일 때 배열의 최댓값 출력
			RESULT = max;
			return;
		}

		Arrays.sort(data);	// 오름차순 정렬

		for (int i = 0; i < N; i++)		// 원 배열의 인덱스를 정렬된 배열의 인덱스로 변환하여 인덱스 트리 접근에 사용
			sortedIndex[data[i].id] = i;

		S = 1;
		while (S < N) S <<= 1;
		tree = new int[S * 2];

		/*
		 * 원 배열의 구간을 정렬된 배열의 인덱스로 변환하여 해당 인덱스에 1을 입력
		 * 인덱스 트리 Build 시 루트 노드에는 구간 크기가 입력되고,
		 * K / 2 + 1번째 숫자가 있는 리프 노드를 탐색
		 * 해당 리프 노드는 정렬된 배열의 인덱스이고,
		 * 원 배열의 인덱스로 변환하여 중앙값 도출
		 */

		for (int i = 0; i < K - 1; i++)						// 구간 체크를 위해 0 인덱스부터 K - 1 개를 1로 표시
			addOne(sortedIndex[i], 1);

		for (int i = M; i < N - M; i++) {					// 모든 구간에 대해서

			if (i != M) addOne(sortedIndex[i - M - 1], -1);	// 이전 구간의 첫 인덱스 -1, 현재 구간의 마지막 인덱스 +1
			addOne(sortedIndex[i + M], 1);

			int id = 1;
			int median = M + 1;

			while (id < S) {								// 중앙값 위치 탐색 (결과값은 정렬된 배열의 인덱스)

				if (tree[(id << 1)] < median) {
					median -= tree[id << 1];
					id = id * 2 + 1;
				} else {
					id = id * 2;
				}

			}

			RESULT = Math.max(RESULT, data[id - S].value);	// 정렬된 배열의 인덱스로 원 배열 중앙값의 최댓값 갱신

		}

	}

	static void addOne(int id, int num) {

		id += S;
		while (id > 0) {
			tree[id] += num;
			id >>= 1;
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class Median implements Comparable<Median> {
	int id, value;
	Median(int id, int value) {
		this.id = id;
		this.value = value;
	}
	@Override
	public int compareTo(Median that) {
		return this.value - that.value;
	}
}