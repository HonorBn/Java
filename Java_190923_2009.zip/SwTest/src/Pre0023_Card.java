import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Pre0023_Card {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K, RESULT, card[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());

		card = new int[N];
		
		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			card[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {
		
		int mid = N / 2;
		
		int stats1 = (int) Math.pow(2, mid);
		int stats2 = (int) Math.pow(2, N - mid);
		
		long sub1[] = new long[stats1];
		long sub2[] = new long[stats2];
		
		getSumOfSubset(sub1, stats1, 0, mid);	// 왼쪽 절반 부분집합의 합 계산
		getSumOfSubset(sub2, stats2, mid, N);	// 오른쪽 절반 부분집합의 합 계산
		
		// "[연습A-0026] 지은이가 지은 집"과 같은 방식으로 풀이
		Arrays.sort(sub1);
		Arrays.sort(sub2);
		
		long sum;
		int tmpR;
		int left = 0;
		int right = 0;
		
		while (left < stats1 && right < stats2) {
			
			sum = sub1[left] + sub2[right];
			
			if (sum < K) left++;
			
			else if (sum > K) right++;
			
			else {
				
				tmpR = right;										// 오른쪽 절반에 정답인 같은 값이 연속되는 경우
				while (tmpR > -1 && sub2[tmpR] == sub2[right]) {	// 왼쪽 포인터를 증가시키기 전에 모두 반영
					RESULT++;
					tmpR++;
				}
				
				left++;
				
			}
			
		}
		
	}
	
	static void getSumOfSubset(long[] sub, int stats, int s, int e) {

		int stat;
		for (int i = 0; i < stats; i++) {		// 비트마스킹으로 부분집합의 합 계산
			stat = i;
			for (int j = s; j < e; j++, stat >>= 1)
				if ((stat & 1) == 1)
					sub[i] += card[j];
		}
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}