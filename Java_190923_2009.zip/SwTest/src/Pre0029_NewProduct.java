import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
 
public class Pre0029_NewProduct {
 
    static StringTokenizer ST;
    static StringBuilder ANSWER;
    static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
    static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));
 
    static int N, Q;
    static long RESULT;
    static Fenwick hat, top, bot, sales;
 
    public static void main(String[] args) throws Exception {
 
        int T = Integer.parseInt(BR.readLine().trim());
 
        for (int tc = 1; tc <= T; tc++) {
 
            input();
 
            process();
 
            print(tc);
 
        }
 
        BR.close();
        BW.close();
 
    }
 
    static void input() throws Exception {
 
        ANSWER = new StringBuilder();
 
        RESULT = 0;
 
        ST = new StringTokenizer(BR.readLine().trim());
 
        N = Integer.parseInt(ST.nextToken());
        Q = Integer.parseInt(ST.nextToken());
 
        hat = new Fenwick(N);
        top = new Fenwick(N);
        bot = new Fenwick(N);
        sales = new Fenwick(N);
 
    }
 
    static void process() throws Exception {
 
        int q;
        for (int i = 0; i < Q; i++) {
 
            ST = new StringTokenizer(BR.readLine().trim());
            q = Integer.parseInt(ST.nextToken());
             
            switch (q) {
            case 1:
                buy(Integer.parseInt(ST.nextToken()), Integer.parseInt(ST.nextToken()),
                    Integer.parseInt(ST.nextToken()), Integer.parseInt(ST.nextToken()));
                continue;
            case 2:
                sale(Integer.parseInt(ST.nextToken()), Integer.parseInt(ST.nextToken()));
                continue;
            case 3:
                now(Integer.parseInt(ST.nextToken()), Integer.parseInt(ST.nextToken()));
                continue;
            default:
                continue;
            }
        }
    }
 
    static void buy(int left, int right, int prod, int cnt) {
 
        switch (prod) {
        case 1:
            hat.rgUpdate(left, right, cnt);
            return;
        case 2:
            top.rgUpdate(left, right, cnt);
            return;
        case 3:
            bot.rgUpdate(left, right, cnt);
            return;
        default:
            return;
        }
 
    }
 
    static void sale(int index, long cnt) {
 
        long min = Math.min(Math.min(hat.rgSum(index) - hat.rgSum(index - 1), top.rgSum(index) - top.rgSum(index - 1)),
                            Math.min(bot.rgSum(index) - bot.rgSum(index - 1), cnt));
 
        hat.rgUpdate(index, index, -min);
        top.rgUpdate(index, index, -min);
        bot.rgUpdate(index, index, -min);
        sales.rgUpdate(index, index, min);
 
    }
 
    static void now(int L, int R) {
 
        RESULT += sales.rgSum(R) - sales.rgSum(L - 1);
 
    }
 
    static void print(int tc) throws Exception {
 
        ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');
 
        BW.write(ANSWER.toString());
 
    }
 
}
 
class Fenwick {
    private int size;
    private long tadd[];
    private long tmul[];
    Fenwick(int size) {
        this.size = size;
        tadd = new long[size + 1];
        tmul = new long[size + 1];
    }
    private void inUpdate(int at, long mul, long add) {
        while (at <= size) {
            tmul[at] += mul;
            tadd[at] += add;
            at += at & -at;
        }
    }
    public void rgUpdate(int left, int right, long cnt) {
        inUpdate(left, cnt, -cnt * (left - 1));
        inUpdate(right + 1, -cnt, cnt * right);
    }
    public long rgSum(int to) {
        if (to == 0) return 0;
        long mul = 0, add = 0;
        int i = to;
        while (i > 0) {
            mul += tmul[i];
            add += tadd[i];
            i -= i & -i;
        }
        return to * mul + add;
    }
}