import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Pst0042_ExclusivePair {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static long COST, RESULT;
	static int N, M, K, E, group[], exPair[][];
	static ExclusivePair list[], sortedList[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = Long.MAX_VALUE;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());

		group = new int[N + 1];
		exPair = new int[K + 1][2];

		list = new ExclusivePair[M + 1];
		sortedList = new ExclusivePair[M + 1];

		for (int i = 1; i <= M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			list[i] = new ExclusivePair(Integer.parseInt(ST.nextToken()),
										Integer.parseInt(ST.nextToken()),
										Integer.parseInt(ST.nextToken()));
		}

		for (int i = 1; i <= K; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			exPair[i][0] = Integer.parseInt(ST.nextToken());
			exPair[i][1] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		for (int i = 1; i <= M; i++) sortedList[i] = list[i];
		Arrays.sort(sortedList, 1, M + 1);

		int mask = 1;
		for (int i = 0; i < K; i++) mask <<= 1;

		for (int i = 0; i < mask; i++) {

			E = 0;
			COST = 0;
			for (int j = 1; j <= N; j++)
				group[j] = j;
			for (int j = 1; j <= M; j++)
				list[j].isExcluded = false;

			search(i);

		}

		if (RESULT == Long.MAX_VALUE) RESULT = -1;

	}

	static void search(int mask) {

		for (int num = mask, digit = K; digit > 0; num >>= 1, digit--)
			list[exPair[digit][num & 1 ^ 1]].isExcluded = true;

		for (int i = 1; i <= M; i++) {

			if (sortedList[i].isExcluded) continue;

			union(sortedList[i]);

		}

		if (E == N - 1) RESULT = Math.min(COST, RESULT);

	}

	static int find(int a) {

		if (group[a] == a) return a;
		else return group[a] = find(group[a]);

	}

	static void union(ExclusivePair edge) {

		int a = find(edge.a);
		int b = find(edge.b);

		if (a == b) return;

		group[a] = b;

		E++;
		COST += edge.c;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class ExclusivePair implements Comparable<ExclusivePair> {
	int a, b, c;
	boolean isExcluded;
	ExclusivePair(int a, int b, int c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}
	@Override
	public int compareTo(ExclusivePair that) {
		return this.c - that.c;
	}
}