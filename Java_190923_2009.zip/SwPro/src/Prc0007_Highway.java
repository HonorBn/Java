import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
import java.util.Arrays;

public class Prc0007_Highway {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, RESULT, G[];
	static Highway W[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		M = Integer.parseInt(BR.readLine().trim());

		W = new Highway[M];
		G = new int[N + 1];

		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			W[i] = new Highway(Integer.parseInt(ST.nextToken()),
							   Integer.parseInt(ST.nextToken()),
							   Integer.parseInt(ST.nextToken()));
		}

	}

	static void process() throws Exception {

		// 간선 배열 정렬
		Arrays.sort(W);

		// 간선 연결 초기화
		for (int i = 1; i <= N; i++) G[i] = i;

		// 간선 연결 및 가중치 합산
		for (int i = 0; i < M; i++) union(W[i]);

	}

	static int find(int a) {

		if (G[a] == a) return a;
		else return G[a] = find(G[a]);

	}

	static void union(Highway w) {

		int a = find(w.s);
		int b = find(w.e);

		if (a == b) return; // 사이클 생성 방지

		G[a] = b;

		RESULT += w.c;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class Highway implements Comparable<Highway> {
	int s, e, c;
	Highway(int s, int e, int c) {
		this.s = s;
		this.e = e;
		this.c = c;
	}
	@Override
	public int compareTo(Highway that) {
		return this.c - that.c;
	}
}