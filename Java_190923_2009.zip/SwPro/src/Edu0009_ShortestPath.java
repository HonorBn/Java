import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

public class Edu0009_ShortestPath {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, S, RESULT, costs[];
	static boolean visit[];
	static ShortestPath list[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());

		list = new ShortestPath[N + 1];
		costs = new int[N + 1];
		visit = new boolean[N + 1];

		int a, b, cost;
		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			cost = Integer.parseInt(ST.nextToken());
			list[a] = new ShortestPath(b, cost, list[a]);
			list[b] = new ShortestPath(a, cost, list[b]);
		}

	}

	static void process() {

		PriorityQueue<ShortestPath> que = new PriorityQueue<>();
		Arrays.fill(costs, Integer.MAX_VALUE);

		costs[S = 1] = 0;
		que.offer(new ShortestPath(S, costs[S]));

		ShortestPath fromCity, toCity;
		int from, to, fromCost, toCost;

		while (!que.isEmpty()) {

			fromCity = que.poll();
			from = fromCity.num;
			fromCost = fromCity.cost;

			if (from == N) break;
			if (visit[from]) continue;
			
			visit[from] = true;
			toCity = list[from];

			while (toCity != null) {

				to = toCity.num;
				toCost = toCity.cost;

				if (!visit[to] && fromCost + toCost < costs[to]) {
					costs[to] = fromCost + toCost;
					que.offer(new ShortestPath(to, costs[to]));
				}

				toCity = toCity.next;

			}
		}

		RESULT = costs[N] == Integer.MAX_VALUE ? -1 : costs[N];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class ShortestPath implements Comparable<ShortestPath> {
	int num, cost;
	ShortestPath next;
	ShortestPath(int num, int cost) {
		this.num = num;
		this.cost = cost;
	}
	ShortestPath(int num, int cost, ShortestPath next) {
		this.num = num;
		this.cost = cost;
		this.next = next;
	}
	@Override
	public int compareTo(ShortestPath other) {
		return this.cost - other.cost;
	}
}