import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0006_LongestCity {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, D[][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		D = new int[N + 1][N + 1];

		for (int i = 1; i <= N; i++)
			for (int j = 1; j <= N; j++)
				if (i == j) D[i][j] = 0;
				else D[i][j] = Integer.MAX_VALUE;

		for (int i = 1; i <= N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 1; j <= N; j++)
				D[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		for (int k = 1; k <= N; k++)
			for (int s = 1; s <= N; s++)
				for (int e = 1; e <= N; e++)
					D[s][e] = Math.min(D[s][e], D[s][k] + D[k][e]);

		for (int s = 1; s <= N; s++)
			for (int e = 1; e <= N; e++)
				if (D[s][e] > RESULT)
					RESULT = D[s][e];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}
}