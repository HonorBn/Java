import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0022_Histogram {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, top, bar[], stack[];
	static long RESULT;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		top = -1;
		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		bar = new int[N];
		stack = new int[N];

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			bar[i] = Integer.parseInt(ST.nextToken());

	}
	
	static void process() throws Exception {
		
		/*	현재 막대의 높이보다
			양옆이 높으면 사각형을 더 확장할 수 있고, 
			양옆이 낮으면 사각형의 좌우 경계이다.
			Stack에는 사각형을 만들 후보 막대를 저장한다.	*/
		
		long width, height;
		for (int i = 0; i < N; i++) {

			while (!isEmpty() && bar[peek()] > bar[i]) {	// Stack이 비었거나 현재 막대보다 Top 막대가 높을 때

				height = bar[pop()];						// Stack의 Top으로 직사각형 형성 시작 (해당 높이 height기록)
															// pop() 이유 : Stack의 Top보다 낮은 막대인 left를 계산하기 위해

				width = isEmpty() ? i : i - peek() - 1;		// width = right - left + 1
															// right = i - 1
															// left  = pop() 이후의 Top + 1
															// Stack의 Top을 pop한 뒤에 Stack이 비었다는 건
															// Stack의 Top보다 작은 막대가 없었다는 의미이므로 left = 0
				
				RESULT = Math.max(RESULT, width * height);	// 최대 넓이 갱신

			}

			push(i);	// 사각형 만들 수 있는 후보 push

		}
		
		// 위 반복문에서 오른쪽 끝이 막혀있는 경우만 고려했으므로
		// (즉, 오른쪽 끝이 막혀있는 경우는 모두 고려했으므로)
		// 오른쪽 끝이 N - 1인 사각형을 확인
		while (!isEmpty()) {

			height = bar[pop()];

			width = isEmpty() ? N : N - peek() - 1;		// width = right - left + 1
														// right = N - 1
														// left  = pop() 이후의 Top + 1
														// Stack의 Top을 pop한 뒤에 Stack이 비었다는 건
														// Stack의 Top보다 작은 막대가 없었다는 의미이므로 left = 0

			RESULT = Math.max(RESULT, width * height);

		}

	}

	static boolean isEmpty() { return top == -1; }
	static void push(int num) { if (top != N - 1) stack[++top] = num; }
	static int peek() { return isEmpty() ? -1 : stack[top]; }
	static int pop() { int tmp = stack[top]; stack[top--] = 0; return tmp; }

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}