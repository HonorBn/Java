import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Edu0031_MaxMin {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, Q, S, sumMax, sumMin, max[], min[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		sumMax = 0;
		sumMin = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		Q = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {
		
		// 배열의 시작 인덱스
		S = 1;
		while (S < N) S <<= 1;

		max = new int[S * 2];
		min = new int[S * 2];
		Arrays.fill(min, 10000);
		
		// 초기값 입력
		int num;
		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++) {
			num = Integer.parseInt(ST.nextToken());
			max[S + i] = num;
			min[S + i] = num;
		}

		// 인덱스 트리 구축
		for (int i = S - 1; i > 0; i--) {
			max[i] = max[i * 2] > max[i * 2 + 1] ? max[i * 2] : max[i * 2 + 1];
			min[i] = min[i * 2] < min[i * 2 + 1] ? min[i * 2] : min[i * 2 + 1];
		}
		
		int q, a, b;
		for (int i = 0; i < Q; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			q = Integer.parseInt(ST.nextToken());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			if (q == 0) getMaxMin(a, b);
			else chgNum(a, b);
		}

	}

	static void getMaxMin(int L, int R) {

		int binMax = 0, binMin = 10000;

		L = (L - 1) + S;
		R = (R - 1) + S;

		while (L <= R) {

			if ((L & 1) == 1) {

				binMax = max[L] > binMax ? max[L] : binMax;
				binMin = min[L] < binMin ? min[L] : binMin;

			}

			if ((R & 1) == 0) {

				binMax = max[R] > binMax ? max[R] : binMax;
				binMin = min[R] < binMin ? min[R] : binMin;

			}

			L = (L + 1) / 2;
			R = (R - 1) / 2;

		}

		sumMax += binMax;
		sumMin += binMin;

	}

	static void chgNum(int id, int toNum) {

		id = (id - 1) + S;

		max[id] = toNum;
		min[id] = toNum;

		while (id > 0) {

			id >>= 1;
			max[id] = max[id * 2] > max[id * 2 + 1] ? max[id * 2] : max[id * 2 + 1];
			min[id] = min[id * 2] < min[id * 2 + 1] ? min[id * 2] : min[id * 2 + 1];

		}
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(sumMax).append(' ').append(sumMin).append('\n');

		BW.write(ANSWER.toString());

	}

}