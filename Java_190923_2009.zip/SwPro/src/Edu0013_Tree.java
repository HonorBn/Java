import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0013_Tree {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, RESULT;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			output(tc);
			
		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {
		
		RESULT = Integer.MIN_VALUE;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());
		
		// 크기가 최소인 구간의 크기 저장
		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			RESULT = Math.max(RESULT, Integer.parseInt(ST.nextToken())
									- Integer.parseInt(ST.nextToken()));
		}
		
	}

	static void output(int tc) throws Exception {
		
		// 크기가 최소인 구간의 아름다움(전체 길의 아름다움) 계산
		RESULT = -1 * RESULT + 1;
		
		// 인덱스를 크기가 최소인 구간의 아름다움으로 나눈 나머지 출력 (나무의 높이)
		ANSWER.append('#').append(tc).append('\n').append(RESULT).append('\n');
		for (int i = 0; i < N; i++) ANSWER.append(i % RESULT).append(' ');
		ANSWER.append('\n');
		
		BW.write(ANSWER.toString());

	}

}