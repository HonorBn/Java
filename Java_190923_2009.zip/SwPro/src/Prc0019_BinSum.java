import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Prc0019_BinSum {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, Q, S;
	static long tree[], RESULT;
	static final int MOD = 1000000007;
	
	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		Q = Integer.parseInt(BR.readLine().trim());

	}

	static void process() throws Exception {
		
		// tree 배열의 시작 인덱스
		S = 1;
		while (S < N) S <<= 1;
		
		tree = new long[S * 2];
		
		// 배열의 초기값 입력
		for (int i = 0; i < N; i++) tree[S + i] = i + 1;
		
		// 인덱스 트리 구축
		for (int i = S - 1; i > 0; i--) tree[i] = tree[i * 2] + tree[i * 2 + 1];
		
		int q, x, y;
		for (int i = 0; i < Q; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			q = Integer.parseInt(ST.nextToken());
			x = Integer.parseInt(ST.nextToken());
			y = Integer.parseInt(ST.nextToken());
			if (q == 0) chgNum(x, y);	// 숫자 갱신
			else calcSum(x, y);			// 구간합 질의
		}

		RESULT = (RESULT + MOD) % MOD;

	}

	static void chgNum(int id, int toNum) {

		id = (id - 1) + S;				// tree 배열에서의 index
		long dif = toNum - tree[id];	// 기존 데이터와의 차이

		while (id > 0) {				// 루트 노드까지 차이값 갱신
			tree[id] += dif;
			id >>= 1;
		}
		
	}

	static void calcSum(int L, int R) {

		L = (L - 1) + S;				// tree 배열에서의 index
		R = (R - 1) + S;

		long sum = 0;
		while (L <= R) {

			if ((L & 1) == 1)			// L이 오른쪽 자식일 경우
				sum += tree[L];			// 해당 값을 결과에 합산

			if ((R & 1) == 0)			// R이 왼쪽 자식일 경우
				sum += tree[R];			// 해당 값을 결과에 합산

			L = (L + 1) / 2;			// L이 왼쪽 자식이었다면 부모로 바로 이동
										// L이 오른쪽 자식이었다면 오른쪽 형제로 이동 후 그 부모로 이동
			R = (R - 1) / 2;			// R이 오른쪽 자식이었다면 부모로 바로 이동	
										// R이 왼쪽 자식이었다면 왼쪽 형제로 이동 후 그 부모로 이동

		}

		RESULT += sum % MOD;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}