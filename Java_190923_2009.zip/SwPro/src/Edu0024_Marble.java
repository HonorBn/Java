import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	사용한 상자의 용량을 꽉 차우기 위해서는,
	상자1의 개수를 X, 상자2의 개수를 Y라 할 때 아래의 방정식이 정수해를 가져야 한다
	
	N1 * X + N2 * Y = N
	
	확장 유클리드 호제법으로 X, Y, GCD(N1, N2)을 구하고,
	N이 G = GCD(N1, N2)의 배수가 아닐 경우 -1을 출력한다
	
	ex)
	N = 24, N1 = 6, N2 = 8, X = -12, Y = 12, G = 2라 할 때
	
	6 * (-12) + 8 * 12 = 24
	
	일반적으로 확장 유클리드 호제법의 정수해는 둘 중 하나가 음수이므로 보정이 필요하다
	X를 N2/G=4.0만큼 증가시킬 때 Y는 N1/G=3.0만큼 감소시켜야 위 항등식이 유효하다
	
	X, Y 모두 양수로 보정하기 위해 각각을 기준으로 증감 배수의 상하한 값을 계산한다
	X는 최소 -(-12/4)=3번(하한) 증가시켜야 하고,
	이때 X = -12 + 3 * 4 = 0, Y = 12 - 3 * 3 = 3이다
	Y는 최대 12/3=4번(상한) 감소시킬 수 있고,
	이때 X = -12 + 4 * 4 = 4, Y = 12 - 4 * 3 = 0이다
	
	계산된 상한값보다 하한값이 크면 -1을 출력한다
	그렇지 않으면 상한과 하한으로 계산한 비용 중 작은 값을 출력한다
*/

public class Edu0024_Marble {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static boolean isImpossible;
	static long N, C1, N1, C2, N2, X, Y, G, RESULT;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		isImpossible = false;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Long.parseLong(ST.nextToken());
		C1 = Long.parseLong(ST.nextToken());
		N1 = Long.parseLong(ST.nextToken());
		C2 = Long.parseLong(ST.nextToken());
		N2 = Long.parseLong(ST.nextToken());
		
	}

	static void process() throws Exception {
		
		euclid(N1, N2, N);				// N1 * X + N2 * Y = N 의 정수해
		
		if (N % G > 0) {				// 정수해가 없을 경우 -1 출력
			isImpossible = true;
			return;
		}
		
		long A = N2 / G;				// X의 증감분
		long B = N1 / G;				// Y의 증감분
		long L = ceil(-X, A);			// X 기준으로 계산한 하한
		long U = floor(Y, B);			// Y 기준으로 계산한 상한

		if (L > U) {					// 하한이 상한보다 클 경우 -1 출력
			isImpossible = true;
			return;
		}

		long RESULT1 = C1 * (X + L * A) + C2 * (Y - L * B);
		long RESULT2 = C1 * (X + U * A) + C2 * (Y - U * B);
		
		RESULT = Math.min(RESULT1, RESULT2);
		
	}
	
	static void euclid(long a, long b, long c) {
		long s2, t2, r2, q1, k;
		long s0 = 1, t0 = 0, r0 = a;
		long s1 = 0, t1 = 1, r1 = b;
		while (r1 > 0) {
			q1 = r0 / r1;
			s2 = s0 - q1 * s1;
			t2 = t0 - q1 * t1;
			r2 = r0 - q1 * r1;
			s0 = s1; t0 = t1; r0 = r1;
			s1 = s2; t1 = t2; r1 = r2;
		}
		k = c / r0;
		X = k * s0;
		Y = k * t0;
		G = r0;
	}

	public static long ceil(long a, long b) {
		if (a > 0) return (a - 1) / b + 1;
		else return -(-a / b);
	}

	public static long floor(long a, long b) {
		if (a >= 0) return a / b;
		else return -((-a - 1) / b + 1);
	}
	
	static void print(int tc) throws Exception {

		if (isImpossible)
			ANSWER.append('#').append(tc).append(' ').append(-1).append('\n');
		else
			ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}