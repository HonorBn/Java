import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Prc0023_Alliance {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, Q, RESULT, A[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		Q = Integer.parseInt(BR.readLine().trim());

		A = new int[N + 1];

		for (int i = 1; i <= N; i++) A[i] = i;

	}

	static void process() throws Exception {

		int q, a, b;
		for (int i = 0; i < Q; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			q = Integer.parseInt(ST.nextToken());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			if (q == 0) setAlliance(a, b);
			else getAlliance(a, b);
		}

	}

	static void setAlliance(int a, int b) {

		A[findAlliance(a)] = findAlliance(b);	// a의 조상을 b의 조상의 후손으로 변경

	}

	static void getAlliance(int a, int b) {

		if (findAlliance(a) == findAlliance(b)) RESULT++;

	}

	static int findAlliance(int a) {

		if (A[a] == a) return a;				// a가 조상이면 a 리턴
		else return A[a] = findAlliance(A[a]);	// a의 부모의 조상 검색

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}