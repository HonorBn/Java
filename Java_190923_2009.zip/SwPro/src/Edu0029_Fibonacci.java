import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/*
 * 피보나치 수는 행렬의 거듭제곱으로 구할 수 있다.
 * 거듭제곱 구하기 문제를 참고한다.
 */

public class Edu0029_Fibonacci {

	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int D;
	static long N, RESULT[][], V[][][];
	static final int MOD = 1000000007;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = new long[][] { { 1, 0 }, { 0, 1 } };
		ANSWER = new StringBuilder();

		N = Long.parseLong(BR.readLine().trim());

		D = 0;
		long tmpN = N;
		while (tmpN != 0) {
			D++;
			tmpN >>= 1;
		}

		if (D == 0) return;		// 0항은 0을 return한다.

		V = new long[D][2][2];
		V[0][0][0] = 1;
		V[0][0][1] = 1;
		V[0][1][0] = 1;
		V[0][1][1] = 0;

	}

	static void process() throws Exception {

		for (int i = 1; i < D; i++)
			V[i] = multiply(V[i - 1], V[i - 1]);

		long tmpN = N;
		for (int i = 0; i < D; i++, tmpN >>>= 1) {
			if (tmpN % 2 == 0) continue;
			RESULT = multiply(RESULT, V[i]);
		}

	}

	static long[][] multiply(long[][] a, long[][] b) {

		long[][] ret = new long[2][2];

		ret[0][0] = ((a[0][0] * b[0][0] % MOD) + (a[0][1] * b[1][0] % MOD)) % MOD;
		ret[0][1] = ((a[0][0] * b[0][1] % MOD) + (a[0][1] * b[1][1] % MOD)) % MOD;
		ret[1][0] = ((a[1][0] * b[0][0] % MOD) + (a[1][1] * b[1][0] % MOD)) % MOD;
		ret[1][1] = ((a[1][0] * b[0][1] % MOD) + (a[1][1] * b[1][1] % MOD)) % MOD;

		return ret;
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT[0][1]).append('\n');

		BW.write(ANSWER.toString());

	}

}