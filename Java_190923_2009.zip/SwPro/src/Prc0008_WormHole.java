import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Prc0008_WormHole {

	static StringTokenizer ST;
	static StringBuilder RESULT;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, W, E, edges[][];
	static long dist[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = new StringBuilder();
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());
		W = Integer.parseInt(ST.nextToken());

		M = M * 2;
		E = M + W;

		dist = new long[N];
		edges = new int[E][3];

		int a, b, c;
		for (int i = 0; i < M;) {
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			c = Integer.parseInt(ST.nextToken());
			edges[i][0] = a; edges[i][1] = b; edges[i++][2] = c;
			edges[i][0] = b; edges[i][1] = a; edges[i++][2] = c;
		}

		for (int i = M; i < E; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			c = Integer.parseInt(ST.nextToken());
			edges[i][0] = a; edges[i][1] = b; edges[i][2] = -c;
		}

	}

	static void process() throws Exception {

		if (bellman()) RESULT.append("YES");
		else RESULT.append("NO");

	}

	static boolean bellman() {

		for (int i = 0; i < N; i++) dist[i] = 1000000;
		dist[0] = 0;

		for (int i = 1; i < N; i++)
			for (int j = 0; j < E; j++)
				if (dist[edges[j][0] - 1] != 1000000 &&
					dist[edges[j][1] - 1] > dist[edges[j][0] - 1] + edges[j][2])
					dist[edges[j][1] - 1] = dist[edges[j][0] - 1] + edges[j][2];

		for (int j = 0; j < E; j++)
			if (dist[edges[j][1] - 1] > dist[edges[j][0] - 1] + edges[j][2]) return true;

		return false;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}