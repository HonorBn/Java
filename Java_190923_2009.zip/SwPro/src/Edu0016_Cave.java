import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0016_Cave {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, H, bar[], blockCnt[];
	static int minBarCnt, minBlockCnt;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {
		
		minBarCnt = 0;
		minBlockCnt = Integer.MAX_VALUE;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		H = Integer.parseInt(ST.nextToken());

		bar = new int[N];
		blockCnt = new int[H];

		for (int i = 0; i < N; i++)
			bar[i] = Integer.parseInt(BR.readLine().trim());

	}
	
	static void process() throws Exception {
		
		// 종유석과 석순의 시작과 끝 표시
		for (int i = 0; i < N; i++) {
			
			// 석순
			if (i % 2 == 0) {
				blockCnt[0] += 1;
				blockCnt[bar[i]] -= 1;
				
			// 종유석
			} else {
				blockCnt[H-bar[i]] += 1;
			}

		}
		
		// 각 높이의 장애물 수 계산
		for (int i = 1; i < H; i++)
			blockCnt[i] += blockCnt[i - 1];
		
		// 최소 장애물 수와 해당 구간 수 계산
		for (int i = 0; i < H; i++) {

			if (blockCnt[i] > minBlockCnt) continue;

			if (blockCnt[i] < minBlockCnt) {
				minBarCnt = 1;
				minBlockCnt = blockCnt[i];
			} else {
				minBarCnt++;
			}
			
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(minBlockCnt).append(' ').append(minBarCnt).append('\n');

		BW.write(ANSWER.toString());

	}

}