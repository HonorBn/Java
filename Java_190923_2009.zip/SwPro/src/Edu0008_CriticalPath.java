import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

public class Edu0008_CriticalPath {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, D[], T[];
	static CriticalPath L[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());

		D = new int[N + 1];
		T = new int[N + 1];
		L = new CriticalPath[N + 1];

		int from, to, time;
		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			from = Integer.parseInt(ST.nextToken());
			to = Integer.parseInt(ST.nextToken());
			time = Integer.parseInt(ST.nextToken());
			D[to]++;
			L[from] = new CriticalPath(to, time, L[from]);
		}

	}

	static void process() throws Exception {

		Queue<CriticalPath> que = new LinkedList<>();
		que.add(new CriticalPath(1, 0));

		int fromNum, toNum;
		int fromTime, toTime;
		CriticalPath from, to;

		while (!que.isEmpty()) {

			from = que.poll();
			fromNum = from.num;
			fromTime = from.time;

			to = L[fromNum];

			while (to != null) {

				toNum = to.num;
				toTime = to.time;

				D[toNum]--;
				T[toNum] = Math.max(T[toNum], fromTime + toTime);

				if (D[toNum] == 0)
					que.offer(new CriticalPath(toNum, T[toNum]));

				to = to.next;

			}

		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(T[N]).append('\n');

		BW.write(ANSWER.toString());

	}

}

class CriticalPath {
	int num, time;
	CriticalPath next;
	CriticalPath(int num, int time) {
		this.num = num;
		this.time = time;
	}
	CriticalPath(int num, int time, CriticalPath next) {
		this.num = num;
		this.time = time;
		this.next = next;
	}
}