import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설] [교육P-0004] 하노이 타워 중간 과정
	N까지의 원판을 이동할 때, 1(시작 기둥), 2(목표 기둥), 3(임시 기둥)이라고 하면
	원판 N이 1에 있는 경우와 2에 있는 경우로 나눌 수 있다.
	원판 N이 1에 있다면 N-1까지의 원판은 1 또는 3에 있고,
	원판 N이 2에 있다면 N-1까지의 원판은 3 또는 2에 있다.
*/

public class Edu0004_HanoiMid {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static StringBuilder RESULT;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();
		RESULT = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		M = new int[N];

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			M[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {

		if (hanoi(N, 1, 3, 2)) RESULT.append("yes");
		else RESULT.append("no");

	}

	static boolean hanoi(int num, int from, int temp, int to) {

		if (num == 1) {
			if (M[num - 1] == from || M[num - 1] == to) return true;
			else return false;
		}

		if (M[num - 1] == from)
			return hanoi(num - 1, from, to, temp);
		else if (M[num - 1] == to)
			return hanoi(num - 1, temp, from, to);
		else
			return false;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}