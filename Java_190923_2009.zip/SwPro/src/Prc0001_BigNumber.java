import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Prc0001_BigNumber {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K;
	static char str[];
	static MyStack stack;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());
		
		str = BR.readLine().trim().toCharArray();
		stack = new MyStack(N);
	}

	static void process() throws Exception {
		
		int cnt = 0;
		
		for (char ch : str) {	// 각 숫자에 대해서
			
			// stack에 앞 숫자가 있고, 앞 숫자가 현재 숫자보다 작고, 지운 숫자 개수가 K보다 작을 때
			// stack에서 앞 숫자를 제거하고, 지운 숫자 개수 증가
			while (!stack.isEmpty() && stack.peek() < ch && cnt < K) {
				
				stack.pop();
				cnt++;
				
			}
			
			// 현재 숫자 추가
			stack.push(ch);
			
		}
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ');
		for (int i = 0; i <= stack.top; i++) ANSWER.append(stack.arr[i]);
		ANSWER.append('\n');

		BW.write(ANSWER.toString());

	}

}

class MyStack {
	int top, size;
	char[] arr;
	MyStack(int n) {
		this.top = -1;
		this.size = n;
		this.arr = new char[n];
	}
	boolean isFull() { return top == size - 1; }
	boolean isEmpty() { return top == -1; }
	void push(char ch) { if (!isFull()) arr[++top] = ch; }
	char peek() { if (isEmpty()) return '\0'; else return arr[top]; }
	char pop() { char tmp = arr[top]; arr[top--] = '\0'; return tmp; }
}