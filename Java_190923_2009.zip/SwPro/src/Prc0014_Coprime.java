import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	수열 S의 모든 부분집합에 대해 원소들의 최대공약수를 구하면 최소 2^100회 연산을 하므로 시간 초과.
	S(i)를 수열 S의 1번째 원소부터 i번째 원소까지 속해있는 집합이라고 할 때, ( S(0)은 공집합 )
	S(0), S(1), ... , S(N) 각각에 대한 부분집합의 경우의 수와 최대공약수의 개수와의 관계를 확인한다.
	
	수열 S = {2, 4, 3} 일 때,
	S(1) = {2} 이고, S(1)의 부분집합과 최대공약수를 나타내면
	 [S(1)의 부분집합 : 최대공약수] = [∅ : null], [{2} : 2]
	S(2) = {2, 4} 이고, S(2)의 부분집합과 최대공약수를 나타내면
	 [S(2)의 부분집합 : 최대공약수] = [∅ : null], [{2} : 2], [{4} : 4], [{2, 4} : 2]
	
	위 2개 경우를 비교하면
	 1. S(2)의 부분집합에 S(1)의 부분집합이 그대로 넘어왔고  : ∅, {2}
	 2. 위 1번에서 S(1)의 부분집합 ∅, {2}의 최대공약수 null, 2가 그대로 넘어왔다
	 3. S(2)의 부분집합에 S(1)의 부분집합 각각에 2번째 원소 4를 추가한 부분집합이 추가된다 : ∅, {2} → {4}, {2, 4}
	 4. 위 3번에서 S(1)의 부분집합 ∅에 원소 4를 추가한 부분집합이 추가되면서 새로운 최대공약수 4가 추가됐다
	 5. 위 3번에서 S(1)의 부분집합 {2}에 원소 4를 추가한 부분집합이 추가되면서 2, 4의 최대공약수 2의 개수가 증가했다
	 
	점화관계를 구상하면,
	S(i)의 부분집합들로 구한 최대공약수 j의 개수는 (0 < j <= 수열 S의 최대값)
		① 1 (j가 원소 i와 값이 같을 때만) : ∅에 원소 i를 추가한 부분집합
	  +	② S(i-1)의 부분집합들로 구한 최대공약수 j의 개수
	  + ③ S(i-1)에 원소 i를 추가하여 생기는 최대공약수 j의 개수
	
	 * S(i-1)에 원소 i를 추가하여 생기는 최대공약수 j의 개수 계산
		- g = GCD(원소 i, 최대공약수 j) 계산 (0 < j <= 수열 S의 최대값)
		- S(i-1)의 부분집합들로 구한 최대공약수 j의 개수 중에서 g = j인 개수를 모두 더하면 됨 (소스 참고)

	점화식은 dp[i][j] = 수열 S의 1번째 원소부터 i번째 원소까지로 부분집합을 구성하고,
	 				  각 부분집합으로 최대공약수를 구했을 때, 최대공약수 j의 개수
*/

public class Prc0014_Coprime {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, MAX, RESULT;
	static int list[], dp[][];
	static final int MOD = 10000003;
	
	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {
		
		MAX = 0;
		ANSWER = new StringBuilder();
		
		N = Integer.parseInt(BR.readLine().trim());
		
		list = new int[N + 1];
		
		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 1; i <= N; i++) {
			list[i] = Integer.parseInt(ST.nextToken());
			MAX = Math.max(MAX, list[i]);	// 최대공약수 경우의 수 중 최댓값 = 수열 S의 최댓값
		}
		
		// (추가) dp[i]는 dp[i - 1]에만 영향을 받기 때문에 행 2개로만 풀이 가능
		dp = new int[N + 1][MAX + 1];
					
	}

    static void process() throws Exception {
        
        int g;
        for (int i = 1; i <= N; i++) {			// 1번째 원소부터 N번째 원소까지 1개씩 추가하여 부분집합 구성
            
            for (int j = 1; j <= MAX; j++)		// ② S(i-1)의 부분집합들로 구한 최대공약수 j의 개수를
            	dp[i][j] = dp[i - 1][j];		//   S(i)의 부분집합들로 구한 최대공약수 j의 개수에 복사
            
            for (int j = 1; j <= MAX; j++) {
                
                if (dp[i - 1][j] > 0) {			// S(i-1)의 부분집합들로 구한 최대공약수 j의 개수가 0보다 클 때만
                    							// S(i)의 부분집합들로 구한 최대공약수 j의 개수에 합산하는 게 의미 있음
                    g = gcd(j, list[i]);		// ③ g = GCD(원소 i, 최대공약수 j) 계산
                    dp[i][g] += dp[i - 1][j];	//   j = g인 case에 합산
                    dp[i][g] %= MOD;			// a + b (mod p) ≡ a (mod p) + b (mod p) 이므로
                    							// 값이 증가할 때마다 모듈러 연산
                }
                
            }
            
            dp[i][list[i]]++;		// ① j가 원소 i와 값이 같을 때만 1 증가
        }
        
        RESULT = dp[N][1];			// 수열 S의 모든 부분집합에서 최대공약수가 1인 경우의 수
        
    }
		
	static int gcd(int a, int b) {
		if (b == 0) return a;
		else return gcd(b, a % b);
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}