import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	확장 유클리드 호제법을 이용하여 정수해 A, B를 구한다
	
	X * A + Y * B = Z

	주어진 방정식이 정수해를 가지려면 Z가 GCD(X, Y)의 배수여야 한다
	그렇지 않은 경우 -1을 출력한다.

	확장 유클리드 알고리즘의 종료 조건인 r(i+1) = 0 일 때는
	Z = GCD(X, Y) 인 상황이므로,
	Z / GCD(X, Y) 만큼 A와 B에 곱하여 출력한다
*/

public class Edu0005_ExtendedEuclid {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static StringBuilder RESULT;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int X, Y, Z, A, B;
	static boolean isImpossible;
	
	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {
		
		isImpossible = false;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		X = Integer.parseInt(ST.nextToken());
		Y = Integer.parseInt(ST.nextToken());
		Z = Integer.parseInt(ST.nextToken());
		
	}

	static void process() throws Exception {
		
		int G = gcd(X, Y);

		if (Z % G > 0) {					// Z가 GCD(X, Y)의 배수가 아닐 때 -1 출력
			isImpossible = true;
			return;
		}

		int s0 = 1, t0 = 0, r0 = X;
		int s1 = 0, t1 = 1, r1 = Y;
		int s2, t2, r2, q1;

		while (r1 > 0) {					// r = 0이 될 때까지 반복

			q1 = r0 / r1;

			s2 = s0 - q1 * s1;
			t2 = t0 - q1 * t1;
			r2 = r0 - q1 * r1;				// r2 = r0 % r1 와 동치

			s0 = s1; t0 = t1; r0 = r1;		// 반복을 위해 갱신
			s1 = s2; t1 = t2; r1 = r2;

		}

		int c = Z / r0;						// r0 = GCD(A, B)
		A = c * s0;							// A와 B에 k를 곱한다.
		B = c * t0;
		
	}
	
	static int gcd(int a, int b) {
		if (b == 0) return a;
		else return gcd(b, a % b);
	}

	static void print(int tc) throws Exception {
		
		if (isImpossible)
			ANSWER.append('#').append(tc).append(' ').append(-1).append('\n');
		else
			ANSWER.append('#').append(tc).append(' ').append(A).append(' ').append(B).append('\n');

		BW.write(ANSWER.toString());

	}

}