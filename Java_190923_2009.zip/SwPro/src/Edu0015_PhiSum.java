import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	오일러 파이 공식은 N보다 작거나 같은 N의 소인수를 이용한다
	N보다 작거나 같은 소인수는 에라토스테네스의 체 구현 방식을 이용한다
	
	공식을 전개해보면 N에서 N / (N의 소인수)의 형태를 재귀적으로 빼나가는 것을 알 수 있다
	
	N = 6일 경우 N의 소인수는 2, 3
	i. 6
	ii. (i) - (i)/2 = 6 - 6/2 = 3
	ii. (ii) - (ii)/3 = 3 - 3/3 = 2
	
	따라서 ϕ(6) = 2
	
	문제에서 N이 최대 1000000 이므로
	ϕ(1000000)까지의 누적합 phi[1000000]을 미리 계산하고
	phi[R] - phi[L-1]로 답을 구한다
*/

public class Edu0015_PhiSum {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int L, R;
	static long RESULT, P[];
	static final int MAX = 1000000;

	public static void main(String[] args) throws Exception {
		
		getEulerPhi();	// ϕ(n) 누적합 계산
		
		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}
	
	static void getEulerPhi() {
		
		P = new long[MAX + 1];
		
		// i 인덱스 값을 i로 초기화
		for (int i = 1; i <= MAX; i++) P[i] = i;

		// 오일러파이 공식을 이용하여 ϕ(n) 계산
		for (int i = 2; i <= MAX; i++) {
			if (P[i] == i) {
				for (int j = i; j <= MAX; j += i)
					P[j] -= P[j] / i;
			}
		}
		
		// 부분합 출력을 위해 누적합 계산
		for (int i = 2; i <= MAX; i++) P[i] += P[i - 1];
		
	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		L = Integer.parseInt(ST.nextToken());
		R = Integer.parseInt(ST.nextToken());
		
	}

	static void process() throws Exception {

		RESULT = P[R] - P[L - 1];
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}