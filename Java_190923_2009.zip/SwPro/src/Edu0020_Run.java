import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0020_Run {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, capa[], temp[];
	static long RESULT;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		capa = new int[N];
		temp = new int[N];

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			capa[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() {

		mergeSort(0, N - 1);

	}

	static void mergeSort(int s, int e) {

		if (s == e) return;

		int mid = s + e >> 1;
		
		mergeSort(s, mid);		// 왼쪽 절반 정렬
		mergeSort(mid + 1, e);	// 오른쪽 절반 정렬

		int left = s;
		int right = mid + 1;
		for (int i = s; i <= e; i++) {
			
			/* 오른쪽 포인터 값 배치													*/
			/* 왼쪽 절반에서 배치할 원소가 안 남았거나											*/
			/* 오른쪽 절반에서 배치할 원소가 남아있고, 왼쪽 포인터 값보다 오른쪽 포인터 값이 크지 않을 때		*/
			if (left > mid || (right <= e && capa[right] <= capa[left])) {
				temp[i] = capa[right++];
				RESULT += left - s;		// 오른쪽 포인터 선수보다 느린 왼쪽 절반의 선수 Count
			
			/* 왼쪽 포인터 값 배치														*/
			/* 왼쪽 절반에서 배치할 원소가 남아있고,											*/
			/* 오른쪽 절반에서 배치할 원소가 안 남았거나 왼쪽 포인터 값보다 오른쪽 포인터 값이 클 때			*/
			} else {
				temp[i] = capa[left++];
			}

		}
		
		// 정렬된 temp를 stat에 복사
		for (int i = s; i <= e; i++) capa[i] = temp[i];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}