import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.PriorityQueue;

public class Prc0003_PrimeMul {

	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K;
	static long RESULT, P[];
	static PriorityQueue<Long> que;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		K = Integer.parseInt(BR.readLine().trim());
		N = Integer.parseInt(BR.readLine().trim());

		P = new long[K];
		que = new PriorityQueue<>();

		for (int i = 0; i < K; i++)
			P[i] = Long.parseLong(BR.readLine().trim());

		for (int i = 0; i < K; i++)
			que.add(P[i]);

	}

	static void process() throws Exception {
		
		for (int i = 0; i < N; i++) {			// 우선순위 큐에서 N번째 꺼낸 숫자가 N번째로 작은 수

			RESULT = que.poll();
			for (int j = 0; j < K; j++) {		// 우선순위 큐에서 꺼낸 수마다 주어진 소수를 모두 곱하여
				que.add(RESULT * P[j]);			// 큐에 집어넣는다
				if (RESULT % P[j] == 0)	break;	// 중복된 경우를 제외한다
			}
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}