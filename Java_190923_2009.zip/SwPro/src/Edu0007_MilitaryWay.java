import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

public class Edu0007_MilitaryWay {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M, K, T, G[];
	static long RESULT;
	static MilitaryWay roads[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());

		T = M + K;

		G = new int[N + 1];
		roads = new MilitaryWay[T];

		int a, b, c;
		for (int i = 0; i < M; i++) {	// 기존 건설 도로 저장
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			c = Integer.parseInt(ST.nextToken());
			roads[i] = new MilitaryWay(a, b, -c);
			RESULT += c;
		}

		for (int i = M; i < T; i++) {	// 건설 가능 도로 저장
			ST = new StringTokenizer(BR.readLine().trim());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());
			c = Integer.parseInt(ST.nextToken());
			roads[i] = new MilitaryWay(a, b, c);
		}

	}

	static void process() throws Exception {

		// 비용 오름차순 정렬
		Arrays.sort(roads);

		// 도로 초기화
		for (int i = 1; i <= N; i++) G[i] = i;

		// 기존 도로 제거 및 신규 도로 건설
		for (int i = 0; i < T; i++) union(roads[i]);

	}

	static int find(int x) {
		
		if (G[x] == x) return x;
		else return G[x] = find(G[x]);
		
	}

	static void union(MilitaryWay road) {

		int x = find(road.x);
		int y = find(road.y);

		if (x == y) return; // 사이클 생성 방지

		G[x] = y;

		RESULT += road.c;

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class MilitaryWay implements Comparable<MilitaryWay> {
	int x, y, c;
	MilitaryWay(int x, int y, int c) {
		this.x = x;
		this.y = y;
		this.c = c;
	}
	@Override
	public int compareTo(MilitaryWay that) {
		return this.c - that.c;
	}
}