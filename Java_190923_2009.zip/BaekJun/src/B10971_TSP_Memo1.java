import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Stack;
import java.util.StringTokenizer;

public class B10971_TSP_Memo1 {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static final int CACHED_DEPTH = 5;
	static final int MAX = 10 * 1000000 + 1;

	static int N, RESULT, dist[][];
	static HashMap<Integer, Integer> cache[][];

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	@SuppressWarnings("unchecked")
	static void input() throws Exception {

		RESULT = MAX;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		dist = new int[N][N];
		cache = new HashMap[N][CACHED_DEPTH];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				dist[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		Stack<Integer> path = new Stack<>();

		path.push(0);
		int visited = 1 << 0;

		search(path, visited, 0);

		dist = null;
		path = null;
		cache = null;

	}

	static void search(Stack<Integer> path, int visited, int currentLength) {

		int here = path.peek();

		if (path.size() + CACHED_DEPTH >= N) {
			RESULT = Math.min(RESULT, currentLength + dp(here, visited));
			return;
		}

		for (int next = 0; next < N; next++) {

			if ((visited & (1 << next)) > 0 || dist[here][next] == 0) continue;

			path.push(next);
			search(path, visited + (1 << next), currentLength + dist[here][next]);
			path.pop();

		}

	}


	static int dp(int here, int visited) {

		if (visited == (1 << N) - 1)
			if (dist[here][0] == 0) return MAX;
			else return dist[here][0];

		int remaining = N - Integer.bitCount(visited) - 1;

		HashMap<Integer, Integer> tmpMap = cache[here][remaining];
		if (tmpMap != null) {
			Integer tmpCache = tmpMap.get(visited);
			if (tmpCache != null) return tmpCache;
		}
		int ret = MAX;

		for (int next = 0; next < N; next++) {

			if ((visited & (1 << next)) > 0 || dist[here][next] == 0) continue;

			int cand = dp(next, visited + (1 << next)) + dist[here][next];

			ret = Math.min(ret, cand);
		}

		cache[here][remaining] = new HashMap<>();
		cache[here][remaining].put(visited, ret);

		return ret;

	}

	static void print() throws Exception {

		ANSWER.append(RESULT).append('\n');
		BW.write(ANSWER.toString());

	}

}