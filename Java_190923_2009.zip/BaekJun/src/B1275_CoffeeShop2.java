import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class B1275_CoffeeShop2 {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, Q;
	static CoffeeShop2 tree;

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		Q = Integer.parseInt(ST.nextToken());

		tree = new CoffeeShop2(N);

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 1; i <= N; i++) {
			tree.arr[i] = Integer.parseInt(ST.nextToken());
		}

		tree.init(1, 1, N);

	}

	static void process() throws Exception {

		int x, y, a, b, tmp;
		for (int i = 0; i < Q; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			x = Integer.parseInt(ST.nextToken());
			y = Integer.parseInt(ST.nextToken());
			a = Integer.parseInt(ST.nextToken());
			b = Integer.parseInt(ST.nextToken());

			if (x > y) { tmp = x; x = y; y = tmp; }

			ANSWER.append(tree.query(1, 1, N, x, y)).append('\n');

			tree.updateRange(1, 1, N, a, a, b);
//			tree.updatePoint(1, 1, N, a, b - tree.arr[a]);
//			tree.arr[a] = b;

		}

	}

	static void print() throws Exception {

		BW.write(ANSWER.toString());

	}

}

class CoffeeShop2 {

	public int N;
	public long arr[], tree[];

	public CoffeeShop2(int n) {

		int S = 1;
		while (S < n) S <<= 1;

		this.N = n;
		this.arr = new long[N + 1];
		this.tree = new long[S * 2];

	}

	public long init(int node, int start, int end) {

		if (start == end) {
			return tree[node] = arr[start];
		}

		return tree[node] = init(node * 2, start, (start + end) / 2)
						  + init(node * 2 + 1, (start + end) / 2 + 1, end);

	}

//	public void updatePoint(int node, int start, int end, int index, int diff) {
//
//		if (index < start || index > end) {
//			return;
//		}
//
//		tree[node] += diff;
//
//		if (start == end) {
//			return;
//		}
//
//		updatePoint(node * 2, start, (start + end) / 2, index, diff);
//		updatePoint(node * 2 + 1, (start + end) / 2 + 1, end, index, diff);
//
//	}

	public void updateRange(int node, int start, int end, int left, int right, int value) {

		if (left > end || right < start) {
			return;
		}

		if (start == end) {
			tree[node] = value;
			return;
		}

		updateRange(node * 2, start, (start + end) / 2, left, right, value);
		updateRange(node * 2 + 1, (start + end) / 2 + 1, end, left, right, value);

		tree[node] = tree[node * 2] + tree[node * 2 + 1];
	}

	public long query(int node, int start, int end, int left, int right) {

		if (left > end || right < start) {
			return 0;
		}

		if (left <= start && right >= end) {
			return tree[node];
		}

		return query(node * 2, start, (start + end) / 2, left, right)
			 + query(node * 2 + 1, (start + end) / 2 + 1, end, left, right);
	}

}