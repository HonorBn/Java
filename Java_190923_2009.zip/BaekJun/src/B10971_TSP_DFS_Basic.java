import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Stack;
import java.util.StringTokenizer;

public class B10971_TSP_DFS_Basic {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, dist[][];

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = Integer.MAX_VALUE;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		dist = new int[N][N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				dist[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		Stack<Integer> path = new Stack<>();
		boolean visited[] = new boolean[N];

		path.push(0);
		visited[0] = true;

		search(path, visited, 0);

	}

	static void search(Stack<Integer> path, boolean[] visited, int currentLength) {

		if (RESULT <= currentLength) return;

		int here = path.peek();

		if (path.size() == N) {
			if (dist[here][0] != 0) RESULT = Math.min(RESULT, currentLength + dist[here][0]);
			return;
		}

		for (int next = 0; next < N; next++) {

			if (visited[next] || dist[here][next] == 0) continue;

			path.push(next);
			visited[next] = true;
			search(path, visited, currentLength + dist[here][next]);
			visited[next] = false;
			path.pop();

		}

	}

	static void print() throws Exception {

		ANSWER.append(RESULT).append('\n');
		BW.write(ANSWER.toString());

	}

}