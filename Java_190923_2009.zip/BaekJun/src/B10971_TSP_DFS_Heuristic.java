﻿import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Stack;
import java.util.StringTokenizer;

public class B10971_TSP_DFS_Heuristic {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, minEdge[], dist[][];

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = Integer.MAX_VALUE;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		minEdge = new int[N];
		dist = new int[N][N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				dist[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		init();

		Stack<Integer> path = new Stack<>();
		boolean visited[] = new boolean[N];

		path.push(0);
		visited[0] = true;

		search(path, visited, 0);

	}

	static void init() {

		for (int j = 0; j < N; j++) {	// minEdge[j] = j로 도착하는 간선 중 최소 비용
			minEdge[j] = Integer.MAX_VALUE;
			for (int i = 0; i < N; i++)
				if (i != j) minEdge[j] = Math.min(minEdge[i], dist[i][j]);
		}

	}

	static void search(Stack<Integer> path, boolean[] visited, int currentLength) {

		if (RESULT <= currentLength + simpleHeuristic(visited)) return;

		int here = path.peek();

		if (path.size() == N) {
			if (dist[here][0] != 0) RESULT = Math.min(RESULT, currentLength + dist[here][0]);
			return;
		}

		for (int next = 0; next < N; next++) {

			if (visited[next] || dist[here][next] == 0) continue;

			path.push(next);
			visited[next] = true;
			search(path, visited, currentLength + dist[here][next]);
			visited[next] = false;
			path.pop();

		}

	}

	static int simpleHeuristic(boolean visited[]) {

		int ret = minEdge[0];				// 출발지로 도착하는 가장 작은 비용
		for (int i = 0; i < N; i++)			// i에 방문한 적이 없을 때, i에 도착하는 가장 작은 비용을 더한다
			if (!visited[i])
				ret += minEdge[i];
		return ret;

	}

	static void print() throws Exception {

		ANSWER.append(RESULT).append('\n');
		BW.write(ANSWER.toString());

	}

}