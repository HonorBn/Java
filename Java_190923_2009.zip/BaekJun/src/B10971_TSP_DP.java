import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class B10971_TSP_DP {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, dist[][], cache[][];
	static final int MAX = 10 * 1000000 + 1;

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		dist = new int[N][N];
		cache = new int[N][1 << N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				dist[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		int visited = 1 << 0;

		RESULT = shortestPath(0, visited);

	}

	static int shortestPath(int here, int visited) {

		if (visited == (1 << N) - 1)
			if (dist[here][0] == 0) return MAX;
			else return dist[here][0];

		int ret = cache[here][visited];
		if (ret > 0) return ret;
		ret = MAX;

		for (int next = 0; next < N; next++) {

			if ((visited & (1 << next)) > 0 || dist[here][next] == 0) continue;

			int cand = dist[here][next] + shortestPath(next, visited + (1 << next));

			ret = Math.min(ret, cand);

		}

		return cache[here][visited] = ret;

	}

	static void print() throws Exception {

		ANSWER.append(RESULT).append('\n');
		BW.write(ANSWER.toString());

	}

}