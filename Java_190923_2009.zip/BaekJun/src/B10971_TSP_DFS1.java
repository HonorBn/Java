import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Stack;
import java.util.StringTokenizer;

public class B10971_TSP_DFS1 {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, dist[][];

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		dist = new int[N][N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				dist[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		Stack<Integer> path = new Stack<>();
		boolean visited[] = new boolean[N];

		path.push(0);
		visited[0] = true;

		RESULT = shortestPath(path, visited, 0);

	}

	static int shortestPath(Stack<Integer> path, boolean[] visited, int currentLength) {

		if (path.size() == N)
			if (dist[path.peek()][0] == 0) return Integer.MAX_VALUE;
			else return currentLength + dist[path.peek()][0];

		int ret = Integer.MAX_VALUE;

		for (int next = 0; next < N; next++) {

			int here = path.peek();

			if (visited[next] || dist[here][next] == 0) continue;

			path.push(next);
			visited[next] = true;
			int cand = shortestPath(path, visited, currentLength + dist[here][next]);
			visited[next] = false;
			path.pop();

			ret = Math.min(ret, cand);

		}

		return ret;

	}

	static void print() throws Exception {

		ANSWER.append(RESULT).append('\n');
		BW.write(ANSWER.toString());

	}

}