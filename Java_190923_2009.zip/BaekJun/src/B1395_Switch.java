import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class B1395_Switch {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, M;
	static Switch tree;

	public static void main(String[] args) throws Exception {

		input();

		process();

		print();

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());

		tree = new Switch(N);

	}

	static void process() throws Exception {

		int o, s, t;
		for (int i = 0; i < M; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			o = Integer.parseInt(ST.nextToken());
			s = Integer.parseInt(ST.nextToken());
			t = Integer.parseInt(ST.nextToken());

			if (o == 0) {
				tree.updateRangeLazy(1, 1, N, s, t);
			} else {
				ANSWER.append(tree.queryLazy(1, 1, N, s, t)).append('\n');
			}

		}

	}

	static void print() throws Exception {

		BW.write(ANSWER.toString());

	}

}

class Switch {

	public int N, arr[], tree[], lazy[];

	public Switch(int n) {

		int S = 1;
		while (S < n) S <<= 1;

		this.N = n;
		this.arr = new int[N + 1];
		this.tree = new int[S * 2];
		this.lazy = new int[S * 2];

	}

	public void updateRangeLazy(int node, int start, int end, int left, int right) {

		// Lazy가 홀수일 때만, 자식 노드에 전파 후 제거
		if (lazy[node] % 2 == 1) {
			propaLazy(node, start, end);
		}

		// 탐색 범위와 업데이트 범위가 전혀 다르면 return
		if (left > end || right < start) {
			return;
		}

		// 현재 노드 업데이트 및 Leaf Node가 아닐 때 Lazy 전파
		if (left <= start && right >= end) {
			tree[node] = (end - start + 1) - tree[node];

			if (start != end) {
				lazy[node * 2] += 1;
				lazy[node * 2 + 1] += 1;
			}

			return;
		}

		// 양쪽 자식 노드 탐색
		updateRangeLazy(node * 2, start, (start + end) / 2, left, right);
		updateRangeLazy(node * 2 + 1, (start + end) / 2 + 1, end, left, right);

		// 자식 노드 업데이트가 끝난 상태이므로 현재 노드 업데이트
		tree[node] = tree[node * 2] + tree[node * 2 + 1];
	}

	public long queryLazy(int node, int start, int end, int left, int right) {

		// Lazy가 홀수일 때만, 자식 노드에 전파 후 제거
		if (lazy[node] % 2 == 1) {
			propaLazy(node, start, end);
		}

		// 탐색 범위와 쿼리 범위가 전혀 다르면 return
		if (left > end || right < start) {
			return 0;
		}

		// 탐색 범위가 쿼리 범위에 포함되면 현재 노드 값 return
		if (left <= start && right >= end) {
			return tree[node];
		}

		return queryLazy(node * 2, start, (start + end) / 2, left, right)
			 + queryLazy(node * 2 + 1, (start + end) / 2 + 1, end, left, right);
	}

	private void propaLazy(int node, int start, int end) {

		// 스위치가 반전되므로 자손 노드 개수 - 현재 켜져있는 자손 노드 개수
		tree[node] = (end - start + 1) - tree[node];

		// Leaf Node가 아닐 때 Lazy 전파
		if (start != end) {
			lazy[node * 2] += lazy[node];
			lazy[node * 2 + 1] += lazy[node];
		}

		// Lazy 제거
		lazy[node] = 0;

	}
}