import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Prc0028_Divide {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static short N, RESULT[], paper[][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = new short[2];
		ANSWER = new StringBuilder();

		N = Short.parseShort(BR.readLine().trim());

		paper = new short[N][N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				paper[i][j] = Short.parseShort(ST.nextToken());
		}

	}

	static void process() throws Exception {
		
		// 변의 길이와 좌측 상단의 좌표를 알면 조각 식별 가능	
		// 초기 종이의 변의 길이는 N이고, 좌측 상단의 좌표는 (0, 0)
		divide(N, 0, 0);

	}

//	┌───┐
//	│a│b│ 
//	│─┼─│ 
//	│c│d│ 
//	└───┘
	static short divide(int n, int row, int col) {
		
		// 변의 길이가 1일 때 칠해진 숫자를 그대로 리턴
		if (n == 1) return paper[row][col];
		
		// 4분할하여 각각의 조각 상태 기록
        short a = divide( n / 2, row,         col         );
        short b = divide( n / 2, row,         col + n / 2 );
        short c = divide( n / 2, row + n / 2, col         );
        short d = divide( n / 2, row + n / 2, col + n / 2 );
        
        // 모든 조각이 0으로 칠해져있으면 0 리턴
		if (a == 0 && b == 0 && c == 0 && d == 0) return 0;
		
		// 모든 조각이 1로 칠해져있으면 1 리턴
		else if (a == 1 && b == 1 && c == 1 && d == 1) return 1;
		
		// 부분 종이 4개의 숫자가 일관되지 않고, 조각 개수에 반영되지 않았다면 개수 반영하고 -1 리턴 (반영된 조각임을 표시)
		else {
			if (a != -1) RESULT[a]++;
			if (b != -1) RESULT[b]++;
			if (c != -1) RESULT[c]++;
			if (d != -1) RESULT[d]++;
			return -1;
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT[0]).append(' ').append(RESULT[1]).append('\n');

		BW.write(ANSWER.toString());

	}

}