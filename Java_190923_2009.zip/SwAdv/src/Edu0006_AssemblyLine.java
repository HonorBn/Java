import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0006_AssemblyLine {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, E1, E2, X1, X2, RESULT, D[][], S[][], T[][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		E1 = Integer.parseInt(ST.nextToken());
		E2 = Integer.parseInt(ST.nextToken());
		X1 = Integer.parseInt(ST.nextToken());
		X2 = Integer.parseInt(ST.nextToken());

		D = new int[2][N];
		S = new int[2][N];
		T = new int[2][N - 1];

		for (int i = 0; i < 2; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N; j++)
				S[i][j] = Integer.parseInt(ST.nextToken());
		}

		for (int i = 0; i < 2; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 0; j < N - 1; j++)
				T[i][j] = Integer.parseInt(ST.nextToken());
		}

	}

	static void process() throws Exception {

		D[0][0] = E1 + S[0][0];
		D[1][0] = E2 + S[1][0];

		for (int i = 1; i < N; i++) {

			D[0][i] = Math.min(D[0][i - 1], D[1][i - 1] + T[1][i - 1]) + S[0][i];
			D[1][i] = Math.min(D[1][i - 1], D[0][i - 1] + T[0][i - 1]) + S[1][i];

		}

		RESULT = Math.min(D[0][N - 1] + X1, D[1][N - 1] + X2);

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}