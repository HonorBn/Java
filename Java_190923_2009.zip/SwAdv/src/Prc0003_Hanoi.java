import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설]
	원판이 1개일 때, 바로 옮긴다.
	원판이 2개 이상일 때,
	하나를 제외한 나머지 원판을 임시 기둥에 옮긴다.
	남은 원판 하나를 목표 기둥에 옮긴다.
	임시 기둥에 있는 나머지 원판을 목표 기둥에 옮긴다.
*/

public class Prc0003_Hanoi {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static StringBuilder RESULT;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, CNT;
	static char P[] = { 'A', 'B', 'C' };

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();
		RESULT = new StringBuilder();

		CNT = 0;

		N = Integer.parseInt(BR.readLine().trim());

	}

	static void process() throws Exception {

		hanoi(N, 0, 1, 2);

	}

	static void hanoi(int num, int from, int temp, int to) {

		if (num == 1) {
			move(num, from, to);
			return;
		}

		hanoi(num - 1, from, to, temp);

		move(num, from, to);

		hanoi(num - 1, temp, from, to);

	}

	static void move(int num, int from, int to) {

		CNT++;
		RESULT.append(num).append(" : ").append(P[from]).append(" -> ").append(P[to]).append("\n");

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(CNT).append('\n').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}