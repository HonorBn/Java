import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;

public class Prc0026_House {

	static StringBuilder ANSWER;
	static StringBuilder RESULT;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int X, N, part[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();
		RESULT = new StringBuilder();

		X = Integer.parseInt(BR.readLine().trim());
		N = Integer.parseInt(BR.readLine().trim());
		
		X *= 10000000;
		part = new int[N];
		
		for (int i = 0; i < N; i++)
			part[i] = Integer.parseInt(BR.readLine().trim());
		
	}

	static void process() throws Exception {
		
		// 막대 길이 오름차순 정렬
		Arrays.sort(part);
		
		int sum;
		int left = 0;
		int right = N - 1;
		
		// 양끝에서 재료를 1개씩 선택해서 구멍 막기
		while (left < right) {
			
			sum = part[left] + part[right];
			
			if (sum < X) left++;		// 부족하면 왼쪽 재료 인덱스 증가
			else if (sum > X) right--;	// 넘치면 오른쪽 재료 인덱스 감소
			else break;					// 완벽히 막으면 종료
			
		}
		
		// 재료를 모두 선택해보지 않았으면 성공
		if (left < right)
			RESULT.append("yes").append(' ').append(part[left]).append(' ').append(part[right]);
		
		// 재료를 모두 선택해봤으면 실패
		else 
			RESULT.append("danger");
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}