import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0007_BarCut {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, V[], D[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();
		
	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		
		V = new int[N + 1];
		D = new int[N + 1];

		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 1; i <= N; i++)
			V[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {

		for (int part = 1; part <= N; part++)
			for (int total = 1; total <= N; total++)
				if (part <= total)
					D[total] = Math.max(D[total], V[part] + D[total - part]);

		RESULT = D[N];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}
	
}