import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

// D[i][j] : i번째 보석까지 고려했을 때 j Kg만큼 담을 수 있을 때 최대 가치
// 1차원 배열로 풀어볼 것

public class Edu0012_StealJewelry {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	// N : 보석 개수
	// M : 최대 무게
	// C : 보석별 가치
	// W : 보석별 무게
	// D : [보석 종류][무게 종류]
	static int N, M, C[], W[];
	static long RESULT, D[][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		N = Integer.parseInt(ST.nextToken());
		M = Integer.parseInt(ST.nextToken());

		C = new int[N + 1];
		W = new int[N + 1];
		D = new long[N + 1][M + 1];

		for (int i = 1; i <= N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			C[i] = Integer.parseInt(ST.nextToken());
			W[i] = Integer.parseInt(ST.nextToken());
		}

	}

/*
		무게	 1    2    3    4    5    6    7    8    9    10
	보석   0    0    0    0    0    0    0    0    0    0    0 
	5   0    0    0    0    0   10   10   10   10   10   10
	4   0    0    0    0   40   40   40   40   40   50   50
	6   0    0    0    0   40   40   40   40   40   50   70
	3   0    0    0   50   50   50   50   90   90   90   90
 */
	
	static void process() throws Exception {

		for (int jwl = 1; jwl <= N; jwl++)
			for (int wgt = 1; wgt <= M; wgt++)
				if (wgt < W[jwl]) D[jwl][wgt] = D[jwl - 1][wgt];
//											[jwl번째 보석을 담는 경우]           	[jwl번째 보석을 담지 않는 경우]
//											 jwl번째 보석의 가치					 jwl-1번째 보석까지 사용한
//										   + jwl번째 보석의 무게를 뺀				 wgt 무게의 최대 가치
//											  무게의 최대 가치
				else D[jwl][wgt] = Math.max(C[jwl] + D[jwl - 1][wgt - W[jwl]], D[jwl - 1][wgt]);

		RESULT = D[N][M];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}
}