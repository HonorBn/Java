import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

/*	[해설] [연습A-0024] 거듭제곱 구하기 
	거듭제곱의 지수를 2진수로 나타내어 계산 횟수를 줄인다
*/

public class Prc0024_Power {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static long A, M, RESULT;
	static final int MOD = 1000000007;

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 1;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());

		A = Long.parseLong(ST.nextToken());
		M = Long.parseLong(ST.nextToken());

	}

	static void process() {
		
		int degree;
		long tmp, tmpM, V[];
		
		// 지수의 2진수 자리수를 계산하여 거듭제곱 값을 저장할 배열 선언
		tmpM = M;
		degree = 0;
		while (tmpM != 0) {
			degree++;
			tmpM >>>= 1;
		}

		V = new long[degree];
		V[0] = A;
		
		// 지수의 2진수 자리수별 거듭제곱 값 저장
		for (int i = 1; i < degree; i++) {
			tmp = V[i - 1] % MOD;
			V[i] = (tmp * tmp) % MOD;
		}

		// 지수의 2진수 자리수가 1일 때 결과값 갱신
		tmpM = M;
		degree = 0;
		while (tmpM != 0) {
			if (tmpM % 2 != 0) RESULT = (RESULT * V[degree]) % MOD;
			tmpM >>>= 1;
			degree++;
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}