import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Edu0002_Polynomial {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N;
	static long RESULT, P[][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();
		
	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		
		P = new long[N][2];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			P[i][0] = Long.parseLong(ST.nextToken());
			P[i][1] = Long.parseLong(ST.nextToken());
		}

	}

	static void process() throws Exception {

		for (int i = 1; i < N; i++) {
			P[i][0] -= P[0][0];
			P[i][1] -= P[0][1];
		}

		for (int i = 1; i < N - 1; i++)
			RESULT += P[i][0] * P[i + 1][1] - P[i + 1][0] * P[i][1];

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(String.format("%d.%d", RESULT / 2, RESULT % 2 == 0 ? 0 : 5)).append('\n');

		BW.write(ANSWER.toString());

	}
}