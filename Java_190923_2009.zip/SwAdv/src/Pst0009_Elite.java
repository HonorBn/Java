import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Pst0009_Elite {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, list[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		list = new int[N];

		for (int i = 0; i < N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			list[Integer.parseInt(ST.nextToken()) - 1] = Integer.parseInt(ST.nextToken());
		}	// 공격력 순으로 정렬하는 시간 절약

	}

	static void process() throws Exception {

		int min = Integer.MAX_VALUE;

		for (int i = 0; i < N; i++) {
			
			// 현재 병사의 방어력이 지금껏 갱신된 최고 방어력보다 높을 때, 병사를 차출하고 최고 방어력 갱신
			if (list[i] < min) {
				RESULT++;
				min = list[i];
			}
			
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}