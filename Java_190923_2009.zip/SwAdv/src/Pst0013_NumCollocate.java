﻿import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Pst0013_NumCollocate {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, table[][];
	static boolean isPicked[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		table = new int[N + 1][N + 1];
		isPicked = new boolean[N + 1];
		
		for (int i = 1; i <= N; i++) {
			ST = new StringTokenizer(BR.readLine().trim());
			for (int j = 1; j <= N; j++)
				table[i][j] = Integer.parseInt(ST.nextToken());
		}
	}

	static void process() throws Exception {

		pickNum(1, 0);

	}

	static void pickNum(int digit, int result) {
		
		// N번째 위치까지 선택했을 때 최대 점수 갱신
		if (digit > N) {
			RESULT = Math.max(RESULT, result);
			return;
		}
		
		for (int n = 1; n <= N; n++) {	// N개 숫자 중에서
			
			// 선택한 숫자는 continue
			if (isPicked[n]) continue;
			
			// 선택 여부 표시하고 다음 위치 선택
			isPicked[n] = true;
			pickNum(digit + 1, result + table[n][digit]);
			isPicked[n] = false;

		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}