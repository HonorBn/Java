import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

/* [사전A-0025] 컬러코드  */

public class Solution {

	static StringBuilder RESULT;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, Q;
	static char part[][][], goal[][][];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = new StringBuilder();
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());

		part = new char[N][8][8];

		for (int i = 0; i < N; i++)
			for (int j = 0; j < 8; j++)
				part[i][j] = BR.readLine().trim().toCharArray();

		Q = Integer.parseInt(BR.readLine().trim());

		goal = new char[Q][8][8];

		for (int i = 0; i < Q; i++)
			for (int j = 0; j < 8; j++)
				part[i][j] = BR.readLine().trim().toCharArray();

	}

	static void process() throws Exception {

		for (int i = 0; i < Q; i++) {
			
			// 문제 1개당, 완전 탐색
			
		}

	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}