﻿import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class Pst0010_BlockArrange {

	static StringTokenizer ST;
	static StringTokenizer ST1;
	static StringTokenizer ST2;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, K, RESULT;
	static Block list[];
	static boolean isPicked[];

	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		ST1 = new StringTokenizer(BR.readLine().trim());
		ST2 = new StringTokenizer(BR.readLine().trim());

		N = Integer.parseInt(ST.nextToken());
		K = Integer.parseInt(ST.nextToken());
		
		list = new Block[N];
		isPicked = new boolean[N];
		
		for (int i = 0; i < N; i++)
			list[i] = new Block(Integer.parseInt(ST1.nextToken()), Integer.parseInt(ST2.nextToken()));
		
	}

	static void process() throws Exception {
		
		int max, id;
		
		// K번째 순서부터 1번째 순서까지 블록 선택
		for (int i = K; i > 0; i--) {
			
			id = 0;
			max = 0;
			
			for (int j = 0; j < N; j++) {	// 모든 블록 중에서
				
				// 이미 선택되었거나 현재 순서에 배치될 수 없으면 continue
				if (isPicked[j] || list[j].order < i) continue;
				
				// 현재 순서에 배치될 수 있는 블록 중에서 점수가 가장 높은 블록을 선택
				if (list[j].score > max) {
					
					id = j;
					max = list[j].score;
					
				}
				
			}
			
			isPicked[id] = true;
			RESULT += list[id].score;
			
		}
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class Block {
	int score, order;
	Block(int score, int order) {
		this.score = score;
		this.order = order;
	}
}