import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;
import java.util.Arrays;
import java.util.Queue;
import java.util.LinkedList;

public class Prc0022_PrimePath {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int BF, AF, RESULT;
	static int[] digit = {1000, 100, 10, 1};
	static boolean visit[] = new boolean[10000];
	static boolean prime[] = new boolean[10000];
	static Queue<Number> que = new LinkedList<>();

	public static void main(String[] args) throws Exception {

		getPrime();
		
		int T = Integer.parseInt(BR.readLine().trim());
		
		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}
	
	static void getPrime() {
		
		int index;
		for (int i = 2; i < 10000; i++) {		// 소수판별 : 에라토스테네스의 체
			
			if (prime[i]) continue; 
			
			index = i << 1;
			while (index < 10000) {
				prime[index] = true;
				index += i;
			}
			
		}
		
	}
	
	static void input() throws Exception {

		RESULT = 0;
		ANSWER = new StringBuilder();

		ST = new StringTokenizer(BR.readLine().trim());
		BF = Integer.parseInt(ST.nextToken());
		AF = Integer.parseInt(ST.nextToken());
		
	}

	static void process() throws Exception {
		
		if (BF == AF) return;			// 시작과 끝이 같으면 바로 종료
		
		visit[BF] = true;
		que.offer(new Number(BF, 0));
		
		Number tmp;
		int org, bf, af, cnt;
		int arr[] = new int[4];
		
		while (!que.isEmpty()) {
			
			tmp = que.poll();
			bf = tmp.num;
			cnt = tmp.cnt;
			
			if (bf == AF) {								// 끝에 도달하면 이동횟수 출력
				RESULT = cnt;
				break;
			}
			
			for (int i = 0; i < 4; i++) {				// 각 자리 숫자를 배열에 기록
				arr[i] = bf / digit[i];
				bf %= digit[i];
			}
			
			for (int i = 0; i < 4; i++) {
				
				org = arr[i];							// 바꿀 자리의 기존 숫자 기록
				
				for (int j = 0; j < 10; j++) {
					
					af = 0;
					arr[i] = j;							// 숫자 변경
					
					for (int k = 0; k < 4; k++)			// 배열의 각 자릿수로 숫자 생성
						af += arr[k] * digit[k];
					
					if (af < 1000) continue;			// 1000보다 작거나
					if (visit[af]) continue;			// 이미 고려한 숫자이거나
					if (prime[af]) continue;			// 소수가 아니면 continue
					
					visit[af] = true;
					que.offer(new Number(af, cnt + 1));	// 이동횟수 증가시키고 Queue offer
					
				}
				
				arr[i] = org;							// 기존 숫자 복원
			}
			
		}
		
		Arrays.fill(visit, false);
		que.clear();
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}

class Number {
	int num, cnt;
	Number(int num, int cnt) {
		this.num = num;
		this.cnt = cnt;
	}
}