import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Stack;
import java.util.StringTokenizer;

public class Prc0020_Tower {

	static StringTokenizer ST;
	static StringBuilder ANSWER;
	static BufferedReader BR = new BufferedReader(new InputStreamReader(System.in));
	static BufferedWriter BW = new BufferedWriter(new OutputStreamWriter(System.out));

	static int N, RESULT, tower[];
	static final int MOD = 1000000007;
	static Stack<Integer> s = new Stack<>();
	
	public static void main(String[] args) throws Exception {

		int T = Integer.parseInt(BR.readLine().trim());

		for (int tc = 1; tc <= T; tc++) {

			input();

			process();

			print(tc);

		}

		BR.close();
		BW.close();

	}

	static void input() throws Exception {
		
		RESULT = 0;
		ANSWER = new StringBuilder();

		N = Integer.parseInt(BR.readLine().trim());
		
		tower = new int[N];
		
		ST = new StringTokenizer(BR.readLine().trim());
		for (int i = 0; i < N; i++)
			tower[i] = Integer.parseInt(ST.nextToken());

	}

	static void process() throws Exception {
		
		for (int i = 0; i < N; i++) {
			
			while (!s.empty()) {
				
				if (tower[i] < tower[s.peek()]) {			// 현재 탑보다 Stack의 top인 탑이 높을 때
					RESULT = (RESULT + s.peek() + 1) % MOD;	// Stack의 top이 현재 탑의 레이저를 수신
					break;									// Stack의 top은 여전히 레이저 수신 후보이므로 pop 안함
				}

				s.pop();	// Stack의 top보다 현재 탑이 높으면, 현재 탑이 레이저 수신 후보이고 Stack의 top은 Pop
			}

			s.push(i);		// Stack이 비어있거나, Stack의 top인 탑보다 현재 탑이 높을 때 push
							//                (현재 탑이 이후 탑의 레이저를 수신하는 최우선 후보)
		}
		
		s.clear();			// 이후 Test Case를 위한 clear
		
	}

	static void print(int tc) throws Exception {

		ANSWER.append('#').append(tc).append(' ').append(RESULT).append('\n');

		BW.write(ANSWER.toString());

	}

}