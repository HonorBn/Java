package example;
public class SegmentTree {

	public int N;
	public long arr[], tree[], lazy[];

	public SegmentTree(int n) {

		int S = 1;
		while (S < n) S <<= 1;

		this.N = n;
		this.arr = new long[N + 1];
		this.tree = new long[S * 2];
		this.lazy = new long[S * 2];

	}

	public long init(int node, int start, int end) {

		// Leaf Node 이면 값 복사
		if (start == end) {
			return tree[node] = arr[start];
		}

		// Leaf Node 아니면 자식 탐색 계속 진행
		return tree[node] = init(node * 2, start, (start + end) / 2)
						  + init(node * 2 + 1, (start + end) / 2 + 1, end);

	}

	// Point Update는 자식의 값이 필요없기 때문에 밑으로 내려가면서 갱신한다.
	// 값 증감이 아닌 값 변경일 경우 차이값을 넘기고, 업데이트 완료 후에 arr 배열을 갱신한다.
	public void updatePoint(int node, int start, int end, int index, int diff) {

		// 탐색 범위와 업데이트 범위가 전혀 다르면 return
		if (index < start || index > end) {
			return;
		}

		// 현재 노드 업데이트
		tree[node] += diff;

		// Leaf Node이면 return
		if (start == end) {
			return;
		}

		// 양쪽 자식 노드 탐색
		updatePoint(node * 2, start, (start + end) / 2, index, diff);
		updatePoint(node * 2 + 1, (start + end) / 2 + 1, end, index, diff);

	}

	// Range Update는 현재 노드가 담당하는 자식들의 값이 필요하기 때문에 (자식 노드가 몇 개인지 모르므로) Leaf Node를 갱신하고 위로 올라오면서 갱신한다.
	public void updateRange(int node, int start, int end, int left, int right, int diff) {

		// 탐색 범위와 업데이트 범위가 전혀 다르면 return
		if (left > end || right < start) {
			return;
		}

		// Leaf Node이면 현재 노드 업데이트 및 return
		if (start == end) {
			tree[node] += diff;
			return;
		}

		// 양쪽 자식 노드 탐색
		updateRange(node * 2, start, (start + end) / 2, left, right, diff);
		updateRange(node * 2 + 1, (start + end) / 2 + 1, end, left, right, diff);

		// 자식 노드 업데이트가 끝난 상태이므로 현재 노드 업데이트
		tree[node] = tree[node * 2] + tree[node * 2 + 1];
	}

	public void updateRangeLazy(int node, int start, int end, int left, int right, int diff) {

		// Lazy가 남았을 때, 자식 노드에 전파 후 제거
		if (lazy[node] != 0) {
			propaLazy(node, start, end);
		}

		// 탐색 범위와 업데이트 범위가 전혀 다르면 return
		if (left > end || right < start) {
			return;
		}

		// 현재 노드(대표 노드) 업데이트 및 Leaf Node가 아닐 때 Lazy 전파
		// 보통 인터넷 블로그를 보면 대표 노드에 Lazy를 기록한다고 개념 설명은 하지만,
		// 코드 상으로는 현재 노드에 방문한 김에 현재 노드를 업데이트하고 자식 노드의 Lazy로 전파한다.
		if (left <= start && right >= end) {
			tree[node] += (end - start + 1) * diff;

			if (start != end) {
				lazy[node * 2] += diff;
				lazy[node * 2 + 1] += diff;
			}

			return;
		}

		// 양쪽 자식 노드 탐색
		updateRangeLazy(node * 2, start, (start + end) / 2, left, right, diff);
		updateRangeLazy(node * 2 + 1, (start + end) / 2 + 1, end, left, right, diff);

		// 자식 노드 업데이트가 끝난 상태이므로 현재 노드 업데이트
		tree[node] = tree[node * 2] + tree[node * 2 + 1];
	}

	public long query(int node, int start, int end, int left, int right) {

		// 탐색 범위와 쿼리 범위가 전혀 다르면 0 return
		if (left > end || right < start) {
			return 0;
		}

		// 탐색 범위가 쿼리 범위에 포함되면 현재 노드 값 return
		if (left <= start && right >= end) {
			return tree[node];
		}

		// 양쪽 자식 노드 쿼리 결과 return
		return query(node * 2, start, (start + end) / 2, left, right)
			 + query(node * 2 + 1, (start + end) / 2 + 1, end, left, right);
	}

	public long queryLazy(int node, int start, int end, int left, int right) {

		// Lazy가 남았을 때, 자식 노드에 전파 후 제거
		if (lazy[node] != 0) {
			propaLazy(node, start, end);
		}

		// 탐색 범위와 업데이트 범위가 전혀 다르면 0 return
		if (left > end || right < start) {
			return 0;
		}

		// 탐색 범위가 쿼리 범위에 포함되면 현재 노드 값 return
		if (left <= start && right >= end) {
			return tree[node];
		}

		// 양쪽 자식 노드 쿼리 결과 return
		return queryLazy(node * 2, start, (start + end) / 2, left, right)
			 + queryLazy(node * 2 + 1, (start + end) / 2 + 1, end, left, right);
	}

	private void propaLazy(int node, int start, int end) {

		// 자손 노드 개수만큼 Lazy 합
		tree[node] += (end - start + 1) * lazy[node];

		// Leaf Node가 아닐 때 Lazy 전파
		if (start != end) {
			lazy[node * 2] += lazy[node];
			lazy[node * 2 + 1] += lazy[node];
		}

		// Lazy 제거
		lazy[node] = 0;

	}
}