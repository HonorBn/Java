package example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

public class BitString {

	private static int T = 20;
	private static int N = 10;

	private static int SCORE[][];

	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		T = Integer.parseInt(br.readLine().trim());

		for (int t = 1; t <= T; t++) {

			N = Integer.parseInt(br.readLine().trim());

			SCORE = new int[N + 1][N + 1];

			for (int n = 1; n <= N; n++) {
				StringTokenizer st = new StringTokenizer(br.readLine());
				for (int n2 = 1; n2 <= N; n2++) {
					SCORE[n][n2] = Integer.parseInt(st.nextToken());
				}
			}

			bw.write("#" + t + " " + calculateSelectNum());
			bw.newLine();

		}

		bw.flush();
		bw.close();

	}

	private static int getMaxBitmaskNumber() throws Exception {

		int i = 1;
		int sum = 1;

		for (int n = 1; n <= N; n++) {
			i = i * 2;
			sum = sum + i;
		}

		return sum;

	}

	private static int calculateSelectNum() throws Exception {

		int allSetBitmask = getMaxBitmaskNumber();

		int[][] sumResult = new int[N + 1][allSetBitmask + 1];	// i번째 숫자까지 놓았을 때, j에는 현재 놓여진 상태 비트마스크

		for (int n = 1; n <= N; n++) {							// n번째 자리에
			for (int n2 = 1; n2 <= allSetBitmask; n2++) {		// n2번째 bitmask
				for (int i = 1; i <= N; i++) {					// i 숫자를 놓으면?
					if ((n2 & (1 << (i - 1))) == 0)				// n2 = 1이고 (비트마스크 자리수)
																// i = 1 일 때 1 & 1 = 0000 0001
																// i = 2 일 때 1 & 2 = 0000 0000
																// i = 3 일 때 1 & 4 = 0000 0000
																// n2 = 2이고 (비트마스크 자리수)
																// i = 1 일 때 2 & 1 = 0000 0000
																// i = 2 일 때 2 & 2 = 0000 0010
																// i = 3 일 때 2 & 4 = 0000 0000
																// n2 = 3이고 (비트마스크 자리수)
																// i = 1 일 때 3 & 1 = 0000 0001
																// i = 2 일 때 3 & 2 = 0000 0010
																// i = 3 일 때 3 & 4 = 0000 0000
																// n2 = 4이고 (비트마스크 자리수)
																// i = 1 일 때 4 & 1 = 0000 0000
																// i = 2 일 때 4 & 2 = 0000 0000
																// i = 3 일 때 4 & 4 = 0000 0100
																// n2 = 5이고 (비트마스크 자리수)
																// i = 1 일 때 5 & 1 = 0000 0001
																// i = 2 일 때 5 & 2 = 0000 0000
																// i = 3 일 때 5 & 4 = 0000 0100
						sumResult[n][(n2 | (1 << (i - 1)))] = Math.max(sumResult[n][(n2 | (1 << (i - 1)))],	sumResult[n - 1][n2] + SCORE[n][i]);
				}
			}
		}

		return sumResult[N][allSetBitmask];

	}

}