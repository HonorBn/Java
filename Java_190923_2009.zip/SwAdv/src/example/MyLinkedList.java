package example;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

class Node {
	int num;
	int wgt;
	Node next;
	Node(int num, int wgt) {				// 가중치 누적한 Node를 Queue에 Offer하는 용도
		this.num = num;
		this.wgt = wgt;
	}
	Node(int num, int wgt, Node next) {		// 연결 리스트에 추가하는 용도
		this.num = num;
		this.wgt = wgt;
		this.next = next;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();

		Node tmp = this;
		while (tmp != null) {

			builder.append("[ num : ").append(tmp.num).append(", wgt : ").append(tmp.wgt).append(" ]  ");

			tmp = tmp.next;
		}

		return builder.toString();}
}

/*
4 5
1 2 1
1 3 3
2 3 5
2 4 3
3 4 1
 */

public class MyLinkedList {

	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));

		StringTokenizer st = new StringTokenizer(br.readLine().trim());

		int N = Integer.parseInt(st.nextToken());
		int M = Integer.parseInt(st.nextToken());

		Node[] list = new Node[N + 1];

		int from, to, wgt;
		for (int i = 0; i < M; i++) {

			st = new StringTokenizer(br.readLine().trim());
			from = Integer.parseInt(st.nextToken());
			to = Integer.parseInt(st.nextToken());
			wgt = Integer.parseInt(st.nextToken());

			list[from] = new Node(to, wgt, list[from]);
		}

		for (int i = 1; i <= N; i++) {

			bw.write(i + " : ");
			if (list[i] != null) bw.write(list[i].toString());
			else bw.write("Null");
			bw.write("\n");

		}

		br.close();
		bw.close();
	}

}